import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";

const whatsappNumber = "5534999999999";
const whatsappMessage = encodeURIComponent("Olá! Vim pelo site da HF Connect e quero solicitar um orçamento.");
const whatsappLink = `https://wa.me/${whatsappNumber}?text=${whatsappMessage}`;

const services = [
  { emoji: "🔵", title: "Fibra Óptica", description: "Fusão, conectorização, testes, passagem de cabo, organização de caixas e manutenção de enlaces ópticos.", points: ["Fusão de fibra", "Power meter", "Organização de rede"] },
  { emoji: "📷", title: "Câmeras e CFTV", description: "Projetos com câmeras Intelbras e similares, DVR/NVR, acesso remoto, cabeamento e posicionamento inteligente.", points: ["Acesso pelo celular", "CFTV residencial", "CFTV empresarial"] },
  { emoji: "🛰️", title: "Starlink", description: "Instalação, melhor posicionamento, organização da rede, Wi‑Fi, roteadores e integração com câmeras.", points: ["Casa e fazenda", "Rede estável", "Melhor cobertura"] },
  { emoji: "📶", title: "Wi‑Fi Profissional", description: "Melhoria de sinal, pontos de acesso, roteadores, repetidores, redes mesh e eliminação de áreas sem cobertura.", points: ["Análise de sinal", "Cobertura total", "Rede para visitas"] },
  { emoji: "🔗", title: "Redes Cabeadas", description: "Cabeamento estruturado, racks, switches, patch panels, identificação dos pontos e organização técnica.", points: ["Pontos de rede", "Rack organizado", "Switches e roteadores"] },
  { emoji: "🔧", title: "Suporte Técnico", description: "Diagnóstico de falhas, manutenção preventiva, configuração de equipamentos e orientação para expansão futura.", points: ["Diagnóstico rápido", "Correção de falhas", "Manutenção preventiva"] },
];

const segments = [
  { emoji: "🏠", title: "Residências", text: "Internet forte nos cômodos, câmeras no celular e rede organizada para o dia a dia." },
  { emoji: "🏢", title: "Empresas", text: "Estrutura confiável para atendimento, câmeras, computadores, impressoras e sistemas." },
  { emoji: "🚜", title: "Fazendas e sítios", text: "Starlink, câmeras, Wi‑Fi externo e soluções para monitoramento remoto da propriedade." },
];

const benefits = [
  "Atendimento técnico, direto e transparente",
  "Instalação limpa, organizada e pensada para manutenção",
  "Soluções para residência, empresa e área rural",
  "Configuração de acesso remoto em câmeras e equipamentos",
  "Rede preparada para expansão futura",
  "Foco em estabilidade, segurança e bom acabamento",
];

const process = [
  { number: "01", title: "Entendimento da necessidade", text: "Você explica o problema ou objetivo: melhorar internet, instalar câmeras, configurar Starlink ou montar uma rede." },
  { number: "02", title: "Avaliação técnica", text: "Análise do ambiente, pontos de instalação, cabeamento, sinal, equipamentos existentes e melhor solução." },
  { number: "03", title: "Instalação organizada", text: "Execução com cuidado no acabamento, identificação, configuração e testes de funcionamento." },
  { number: "04", title: "Entrega e orientação", text: "Você recebe tudo funcionando e entende como acessar, usar e cuidar da estrutura instalada." },
];

function FadeUp({ children, delay = 0 }) {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) setVisible(true); }, { rootMargin: "-60px" });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);
  return (
    <div ref={ref} style={{ opacity: visible ? 1 : 0, transform: visible ? "translateY(0)" : "translateY(28px)", transition: `opacity 0.6s ease ${delay}s, transform 0.6s ease ${delay}s` }}>
      {children}
    </div>
  );
}

const styles = {
  btn: { background: "#38bdf8", color: "#0f172a", fontWeight: 900, fontSize: 15, padding: "14px 28px", borderRadius: 14, textDecoration: "none", display: "inline-flex", alignItems: "center", gap: 8, border: "none", cursor: "pointer", transition: "background 0.2s" },
  btnOutline: { border: "1px solid rgba(125,211,252,0.2)", background: "rgba(255,255,255,0.05)", color: "#fff", fontWeight: 700, fontSize: 15, padding: "14px 28px", borderRadius: 14, textDecoration: "none", display: "inline-flex", alignItems: "center", gap: 8 },
  card: { borderRadius: 28, border: "1px solid rgba(125,211,252,0.1)", background: "rgba(255,255,255,0.04)", padding: 24, backdropFilter: "blur(8px)", transition: "border-color 0.2s, transform 0.2s" },
  sectionEyebrow: { fontSize: 11, fontWeight: 900, textTransform: "uppercase", letterSpacing: "0.28em", color: "#38bdf8", marginBottom: 12 },
  sectionTitle: { fontSize: "clamp(1.8rem, 4vw, 3rem)", fontWeight: 900, letterSpacing: "-0.03em", marginBottom: 16 },
  sectionDesc: { fontSize: 17, color: "#94a3b8", lineHeight: 1.8 },
};

export default function App() {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", fn);
    return () => window.removeEventListener("scroll", fn);
  }, []);

  return (
    <div style={{ minHeight: "100vh", background: "#07111f", color: "#fff", fontFamily: "'Segoe UI', system-ui, sans-serif", overflowX: "hidden" }}>
      {/* BG effects */}
      <div style={{ position: "fixed", inset: 0, zIndex: 0, pointerEvents: "none", background: "radial-gradient(circle at 20% 10%,rgba(56,189,248,0.18),transparent 28%),radial-gradient(circle at 80% 0%,rgba(125,211,252,0.15),transparent 24%),radial-gradient(circle at 50% 100%,rgba(14,165,233,0.12),transparent 32%)" }} />
      <div style={{ position: "fixed", inset: 0, zIndex: 0, pointerEvents: "none", backgroundImage: "linear-gradient(rgba(255,255,255,0.03) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,0.03) 1px,transparent 1px)", backgroundSize: "64px 64px", WebkitMaskImage: "linear-gradient(to bottom,black,transparent 80%)", maskImage: "linear-gradient(to bottom,black,transparent 80%)" }} />

      {/* HEADER */}
      <header style={{ position: "sticky", top: 0, zIndex: 50, borderBottom: "1px solid rgba(186,230,253,0.1)", background: scrolled ? "rgba(7,17,31,0.95)" : "rgba(7,17,31,0.75)", backdropFilter: "blur(24px)", transition: "background 0.3s" }}>
        <div style={{ maxWidth: 1280, margin: "0 auto", padding: "16px 24px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <a href="#topo" style={{ display: "flex", alignItems: "center", gap: 12, textDecoration: "none", color: "#fff" }}>
            <div style={{ width: 48, height: 48, borderRadius: 14, background: "#38bdf8", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 0, boxShadow: "0 0 24px rgba(56,189,248,0.35)", overflow: "hidden" }}><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHgAAAB4CAIAAAC2BqGFAAABCGlDQ1BJQ0MgUHJvZmlsZQAAeJxjYGA8wQAELAYMDLl5JUVB7k4KEZFRCuwPGBiBEAwSk4sLGHADoKpv1yBqL+viUYcLcKakFicD6Q9ArFIEtBxopAiQLZIOYWuA2EkQtg2IXV5SUAJkB4DYRSFBzkB2CpCtkY7ETkJiJxcUgdT3ANk2uTmlyQh3M/Ck5oUGA2kOIJZhKGYIYnBncAL5H6IkfxEDg8VXBgbmCQixpJkMDNtbGRgkbiHEVBYwMPC3MDBsO48QQ4RJQWJRIliIBYiZ0tIYGD4tZ2DgjWRgEL7AwMAVDQsIHG5TALvNnSEfCNMZchhSgSKeDHkMyQx6QJYRgwGDIYMZAKbWPz9HbOBQAAA5YklEQVR42p29ebRlV3EfXFV7n3PHN/YbutWDWmNrQGMjIYEGkDEfNiApgDHYEOzPxp9xwM5aEMyKk3zOgE2yjOPECcZDbGLzLRtnCYMAx2ADRgMCTQjNQ6tbPfd7/eZ3x3P2rvr+2Oece8bbWnksWvfdd+85Z9euXeOvqrBWqwMAACAiVPyI+6sgAgIARB9EEHHfEhD3LgJAdB1xHwAEBBQQAPcyelNEEBBwdI/oMxjdxX0BBABERAAAiaLPcnxf4ejZKXkmYBYASZYj0f/dnWV0cfcPJM/vntJ9EYVZAAjRLSJelhUhRHTPE9FMEvrI6I7Rq/glsq432sn7KVpj8nlEZAAkBAuE5KgF0Q3EvSMi8UKRkJI7YOauAAiIGNMoIT1EtBRJniH9b+5P7p1k8yJCustGmyvJ7UY3cn8FQIrIJCIZZhIZfYBFQESEiNwXBSTZJ0SybJPbResCFBFI8xhL9AsiAGuRZD/SO8Fpiri9dDuPgALgOIkIWNgtM95N5NSmSmoLE5YFGC01Xr/7FdzaAKKjwsyOv9xFmHlE/ZjNR3SSiJrusu52IiPOjThdoi3METp1UkGAYxaW+Bmi/RIQERvvvoAgxDRJFpwcVhEAYLcHOiUbsIy1IfemiKQZH0cnC2NiccXXU0tJXTB15oBi4RAzZHJOHN0z3OCIVfXY8V9Tki4r29LnI8/alYJU0kuIP4OlhEp+c1ui0xSMl1T+zYQLRASRktsgCoBAXlJlLusoUtyq9EkiylA2S8SIm3MPRkRuGaUcmn4zeRG/KbmtTW7n7lSkmltH8Ua5ZaZXiggAJMIAoqNndTpIQEbPhAkLiCQUQYCIyvGTSfzc0eeJsHS1acLljoX7ihMd6bVlmQ7zYjp+hhybF5mUCEUy189tQHbvS3l5pJdL+Dx12dwDOJmKiNF+MkSfzV4ofW+Ml0rZB5JEPudUbvFApN9k5ljJjUiQe/TUGignFpKfhCtLZYj7TJqdi0yAiDm+Lt08InKPkT706RfJdws6HABAR3seKerMoc4+WaRt0hLGyRAnCotrSFMqJXxLZGupjCpuT2RMwYi46ROQ5vHcF1P2WaW+SaiZOv4QKdgCryT3ylpKI+5M8XW0YToiROHEiUDMqlh6nEtNsarPVFE5tXNUegwL0gZFOLFbqs5N4fyWuwiJUM4pobTMSe6VOxmlvJK2kRIyOmNfpzc2u6oS6pSybY6t0lxcKtFejW2Tlg8J4ySW+jktorQEKJXaFdoiJ7Xy7FXciaySj546Z6cjEkCZ1VF6Usa7jlX6pFTY5a6TFgJFK7C4i+PZs1rKlxyC4rPltLdj9uIdq85KUccmZNFpsTuGOlUcNEYLVZkBRW7KmgFQPExjHqaUZ0ttZERMpESV+VzBE4kFWULlHP/mGC55fiq9TeR6pu5XyoxjJWD+uXMrLN7R3TStuIumYZGVxp+zlAjKrCsdYMhFBRLucR8mopw3l15OVqtJqQCIOLpa0VHpktJCMJHCWWshLeUxTXcRBIjCQEmcJHKUETC6Akf0TbFy8UapmJEguG8RZrdXhJ05JMIsgkCEUYQkxXeJNsKiUkkf98Sbr/C8iqZOhjl0rG3yhkeRrDmdmbaEChZYbFRh5NyzgLAI2ySGAIACnISoYomBCGCZZRQyAASw0Rcik4vQGe+OCsgRAQSR4ohKFIZAQORoSYzCkLhlwCxIiJA4uFDqZCb0SblvUqrkyywFEYmupqNtoog+qV2NVpLjXHfjxC5OGcgZi4eUstaGw4CNAWDPU/Va3at5pFUcj5Qo4BkFmgAltUJEYU4e3roglwBHETJBJHAxImFnWAOIgHVxIEwe2AVORWKvyLp9ZWBx0SG2oWVBRcpDQipTbgmtq9RGlXEV23YYWx2pzUgYOusWZmICiVjIStLEEUdrbNjva4927dq1c/+ByZ0X+9PnWa+NuoHKD8MQkZhZgLVSwABiQTgwjEQuciZWEARRjDWWLZGHiGwCy0KonOVPCNbY0SFlCcMwDoILYsQX1rKTT9aGwsyMACLAYC0EPTPYlO7yYP1kb+3EoN83onDkh+bdk1IdnqJyxu1IiQEQQZyZXYxFVT5mVC2AEvmbRJGcOUnMPOj3pqaaF112cP7KN9HC5Vt92thc7W+uhv1NCfsw7Ik1Is7/ZkIkAGZr2TIqcOQRQGsBhcU6Yc1AIoJiQUbB4mg9CGxZLAvGMiOTmyARJEQBYDYI4mJGAiAEqBteY9ab2FFrT7W5K2sv9E/9cGt1eWBYKSIkYQEcnfKcnZ5WnjFBJdGv8ftxamJmdjGW8SOhgQk/pHR0UT2m2VmR7g+6HsI1r79t383vXpOF40de6Z14jDaOK7OlwNAoOZMwAjJbAGC2IkzRYznfjzmKJAmIhALMooWdWnNP76SIuxQLR5Ev972UqAYBdsI5/j0KskgUb2HypDYr0wda510+NburPjyy/eJ3tpZPGfIUJadZ0oGtdIQvrajSjlJee83MLhRDSAU7RNL+Zc7iFhFS1Ot0ztu966a7fmkwe+3zTz5hX3mgFq4AGEIF5Ln1xfkvSasUZhE2CFFCgpmZrQJ26sdRliXOP0RkFfdrxDPCsYWbvJBERktWeyFA9PnRp1msYRuIKJ68QF94+/zCHjzx3c0j3x+EQI7Y2Uj0GCfFydh0jiK67+yOnZDJVmTM2LSB4k5QziJ2+rjf61538MbL3/bRZ0/0Vp74aqt7WCmPUSVmHbOk02SOVI6qAjGDIAozsxU2GkebIXFwL71DCfHSVEwYLcdxFT5b9N/YiyFA4LBvDOuFg82r3truHuo+8/XOMFRKgXDRms75nOlgdNGpcYSORAlG6juzFfHBKUYhgFkQqdfdvuXHf2LX7R9+5KGH5dDX6ioUrAlLys6TbEZGovUJA1hgEzNL9Ic0E3IkQsBJ5uR4RqK2QGJ34SqHOM0fabEb/yqRQA96Qz3ZuOpnp9vcf+qvetsD8hSIIKp0pqIoH6rcfRFRjWarEOKgQpgpiatmuJlQ9bvd2/+vn1y85Z99/1tf849+s+b7LArYChRIAALAIgzCTijHpi5jkl9w4rWMcyHLwrkYSBVNk30a423noqkCAtonHgQnHglaF7b3XY9rLwRBQEphme2cc0xKPRcRVo1mO51ESNsbqUtAnDfJJEa6ve1rb3j93jd/7Aff/nLr9HdVrcnCie/heMR5MCwMYhE5Mq2EEZ3zx1QmDHLrSWIUCZsXratSgubSOpDNjBUjRNHBZxZUmjBceiqcuGRizxW8/ExoM1H1MSG9YkYQEVS90YpTGJAOdRdTkPGXkVkQcTAc7N696/p3/atHH35YH/0H8lrFxDQAIIRJUlWAAIgZhFEAgQVQQBgs2wpOHMO8uSBZKWuXvj6nXxcpXiLSKjj9hOx8Q3tuITjzPIMa5b/LgrpVEXlEUI1Gy7n5qUxE3vnO6MbYtlLEd/zMJ58+HQTP/K+aVgJWxIIwgDBbEIsICE5KAAA7Nw7EIgiLBbYCDCJsTawhebyuy0iSrHgtAj/S/vTYILJURwGFARVIcPZluvAtOjg72Fom0rkoVtqhq8p5AoBqtSazScIMWUuinQhI2O/1Dt7y4/aCtx5/4M8nZMuKAgmZDbMBYBAL7LwS69bLEgIzoSA4deegEezsD5ZyEqdSi1JlPBR/zaWxczG50gNR+XkAQYXhxrA/bFxwqyw9YSyko4xjYkzuyUeyNwe9cNiBUawle3gRERCtMdMzE4s3vOulx++bGJwy4IOEbC04vFQiniOLl5wXNkqYy8hjxySfJFwkQULlxJxI/s395PapeA7cw6clUqlAL5EqwuA1eenRXqfv734tcBCb4FK6u+nMTprulDt6pXmwtHxEwDAYXHL1zeuDCXvsftEgHAibUZ48l9yOCZom1sg6lhTWIUuytMGQI1/OthvjPlSJ6VKgQVW2SEQU4uDo93juGu371hgZoasklSPHilB4HPQiwiTmGZMLne2QS28jIrPU67W5A3eceulHNbMtFoRN8tzWWmstM7t/AQDFCIcJ7XJazlpbKoWT/Ui+kv6pchzG0724PVXsn98wEdR12HgxGPT0/CUQDkt1cjFzkhYvenziMgccQcRgONx/yYWd5t7+yW81iZkRk+hBwcgtLCRjUXBK+0HB8Uuv3Jl3RSqUcuirEb5F/6WKaqNvYRguP+/NH+ATT2DFZqe98Nz1dfJJGiUoMBWSlkwKHRE4WLjw2s31DeqcMEoRmChMnCVZzjEtmmI5OuYM3iovoxjQyQniMcZfkZ2LhseY5DNRjdcPy84DujFnB9uIOgl5njMxjQm4KytapSrzJiKer1rnXbV1+iVltkmsMFuOtF5uwelTnxMF6T9VpVPTYlrKjkbxnSJsLneLtA6KvQ/JgoSk0rJGRf01HgR6YpfYIE2kYpStmKLVWcO53FVJbmetbbcnuD7bX3uiSS4JMopsVemubBQ8MRNRmMcQrsjXRbttBGEGcJoh3pgkLJponmyODTI+KAIwc06h5WUIgsgw6JxptnaIWHkVqeq0CaZTdkUm/5iK8Y+cbra23poeGJ+6qwIESSK14OCmWJuHgyCKBEVxOAFBa63na6V0In+LRCy1ENIiQinV7/d6vZ6nvfbERLPRGAVScyGtBGg+Qq/LCKku4Pl+vz8YDodKqbIzHQVmeLBmm3uiaG/qeYo4ptz3dRLPSTY569GnMRYgYmvNiTC0tr8BUAg4Zl01ZlaKev3er330Vw9ef32/P1AuLoMIIO2J1u/+5//ywP3fa7WbOXu5+G9OjDruC8Kg1+teftnlb37zm284+No9u3c3m01U6BR+FrwgsfqHJJgzwulaW6vXDx06/J6ffi9Alc2H7HhluA3KB1QiLIIJUNSdNnfTnIpyGXR9TpDGyMQGABbPaw6HAzDbQijCSV1J1sYYBfWt4UsPHLjuuuu73a7neUppIgDkmZnpz//PvwiCoCmNnMlcFS1ympBZPE9tb3dmZ2b+1b/8jbvuumtmepqZjTEAgARKEREppTAiODj7tQhDTYjCIh/4wM+fPbsyNTVtrS2D3Du0BIHpASkk5TZbBJQqR8/kADS6iCZwTF2mFiIAtGUWtoyACNZyVNyRDwyO2L3f6/W63X6/H4YhkSYCJKnV6mEYlMriKmPL7YdSamtr64orrvj9//pfL73k0vX19bW1NSJSWhEqcrmZCJBDREjkFlxCaHfNZrP5sY9//Nvf/ubM7GJC5bxmjuxcFLYu2eEexgU1S7+S8w/1GDhSGm2e7JCjNyEAW4nSNhklmzMVmC0iaM+j4ZCIlAJSBCBOFLLwmOhPUfshQqe7femll37+z/5sZnpmeXnZ8zytdYxzEkQkVCMyIyZQ8CKY2lrbbDa/dM+Xf+93f3dqes5aW8x5jyLISd6MGV4FriOnunQuGVNRlzAKfSARIgALEHBcjDUm9O4gCCN/iSIsrINaCUup6VblXxhjG436Z37nM7Mzs1tbW77vp4mBKiqdq8JRpt9n5nq9fuTIkQ//yq/U6+2cAMy9GGXgkhhNFkKfvkWpJKEsmaRihZIAQqK4uMuix3Zx0aobxTPikCARIbjiOIgxbeXORVW0iIi2t7Z+6Rc/dPVVV21sbHieN4LQxUj67Llkh0ArdX8Q0Vr7C7/woeXl5UazlXPQy5xbcVAIimqxIFnhq4nD6JyvVZanyRwUay1Y68IUkBXlsX5IRwlAmBGdsERS5MRnYrZbtqWeSC7Y6H4dDPq7d+9+1zvftbm5qZRKLN8YwIi5Wp2UNQ0JfsJRyVrbarV/4zd+4zvf+db0zIIxJodiLT9eEKGrMk8LQIVqmmJCS5dX2mVq0yRXggoglq2vwcYJ0zRdspIaWYQIkQRRkEQppZRKYd2iU1EaG0onXJRSnU7nrjvv2rlz5/r6uu/7WdgnAMDs7CwiBkGQrosizDiFiOKofO9X7/30f/xPExM7bOzmjHuGGHgJACxWOElnY1VsK5sSEl0a+srCwlNFiinDn1mAyi2NvH0GnDNsU1BHyanpogWdBvxdf/31TmU50icf00rX6/UvfOEv7r333tNnliB2WRAhl4xHVO67Lx065HtNQBKxuYLRkghqIlslkp+xXSsAwizFMGnOEdelFSVpSzvniouIZY5qSDmpgCvBV0QRDzFIkGCN3Y9bW/wtGB9FS2RLvV7fs3fPcDjMhHqRkVStVvvIRz7yhS/8uUsblRaH5Soy642W5/sitjQUVazNip13zm5eykyoKEGMHJZsqnw8sj9GdIEwWyRMcg1FPZOiHyrSSqmEo5PVMjNIZUop75ix9X2/3Wol8Q0kREIRnpmd+cPP/dEXvvDnU9PzKVmHBV7OE9RJ+XNWimRtD4ytvZH5QFmvrWjhZCpncyD4QoVWYk46k05YRJBgbAwoXmDasM3UygnkMym5iGgi951Dr7R2Il4pTSRKAZE3HA7/8q/+Wqm6c6ByJQel8dVXgbgteaT4wCZyFHK+T2m9LSIQkc7mvKuEdQQ3jCC+ibxOJcrSz50k92LYvSQc7XgxqbkrYgpKgx7uCVhEKdRaCbDS6K7peV5nu7O6uqKUxyy5jgrlVUApFQeRDiDXRyB5mpwdHUdKhFkEbHQlxHQpakW1R7Qgnes+UbXzGctEmB1U4FUEKFwldMLRmaulaDK+aioKwKEoAlJIjEqRI7TWmhTFTT4y53IcKCnKuzIimjAIBl1db9a0LykXLGd1RBAqdGUMLEIg4ppSYApTXRCDcVKxiKEqxJVihYgxYpNUylaHdDg/mxJOwfeFk/x6SraUIJKKHM3MAIwCJFRvtDzPi+RR9EMU10tlhFLG7AFOK5OkzB/Rsm1Mzb3lQ785v/eiYWCEPAZBKBSjJ36ZALIkTJmUmZaad+kQP5WKpzKH2EnlBAoa24csudxSKr48so3igueyiwvkMrClqDhE1Mo7ffp0t9udm5ufmZmJa7kckg0pe5BzK+IE4uBgrCIMKkTPsDTmL95x97+56r3/VvxGSGBpVNteksYUoVQzl6rMd7b0JObo0mxe6msU1dogOpuRjXUaQYQFuOg6OxcgYfD03uZBOc4rj3+cNBgZFYjuTaXUYDBYWjp1151vv/rqq97//vc/+uijO3bMOA/br9W0VuAKUATKEgij88oCloUF2Q49TUrVzxx67Pv/35/Ur797/2vvMIMA0Yth+pCvnHCqjRmFqrLvUvGjqwKpJdIW0gVg5GhdhaMtZqxz5xoAOtvbw8HW2pokYbOqgmcEuPrqq26+5Ra/7j/39FNf+crffOUrX/r0p//jr//6JzY3N3fMzl5//XUvPP+0X5t3dWBpSFCSWXFPGKISIhiEV9/9K3uuev03fv+f07B3+jv/bfamu2du+5D+4f2WLQBSefePCBkgMWirNHNYiujVVfQtqTyN2lOJgBVBOVcZZdIcBwHSxYdODhgT3n77rY16o9VqWWuTJE/yiA6YSkoNB72b3vCG9/zsz8Daqh0OJnfvO3X69Ad/7uc++clf33Xeng+8/33dbue3PvVvz5w5c/+DD0HkEEZWQlpiKASv1hQgJCXKrpmZ2cvuvPgN9z/7zf9pNk8cf+DeuTd9YHLflesvPYYqAmQW1CkCs6uXTDAvpYUtRTSSLmahygqJIV3jxi4NSoKvYntk1Ecps//dbu/DH/7wRz/qMRsno40JjTHWRhKbmYlQWGrN5mB17cn/++fxoQdn5+dPvv1t7Tvf9Y1vfOOWW2/757/2q2964607dswuLC7e++Uv//CJJ7a3t1NhbjDGsLXOHzdh8Ml/8+9PLq36GkzNO37fn+HV75y4/v3+A18ynbXOM19Vt/1846Kb1158REiLCaS4oki8h0m+MUG9ZMBcZXW1uhTqUMyYRelJp2pZkpqUMVR2ux1XoIxo7UoFRGRraysFbLLGGGOMNeJ+j++sGu3+fb/wQbnv/mmlaHllz+ra2VNn2p/4xKc+/am73/72L3/5Kx/96EeWlpaU0tddd60IG2OttdbYMLTGGGYeBsHU5OR/+NR/OHH0aHPXhagb4dYKDFbXH/5S+BMfa++5au2575iVQ52zJ7yFqz3PZ1c1igWlJYCADISADCwusF5WLVsCC8nRd0zVW6TWXYlfDKYuxRUm1lt0UDjzOUdaRwJmFmEHJLPGGhMR3LK11oZBoGu1pUceefnBB57z1SNKnvL102eW5h783tG//utrrrl2dsfCd7/7XWMss4RhuLGxsbq6tra2tra65l5sbGycPbsCwvd86Z4/+IP/XpvaAbUmt+bRr7OE5tTjHUOy41JQnvRWefmEae8nXeeqkEBUUxYnxUdsDuny8VLPRacd7mKng2wld9QEjpCErSt2KYYp8rEOFkQHuuA0LCa2TKwxNgxtGBhH4jAM2SWLWMBa3TKnj7x8lMEQEnMotqb1rmPHt779ndpHPrpnz95XjhztdntO4ET7ZUwYWmuY2QZBoJQ6fvzYb33606o+SbVmaEICIlW3pOzWEnY60N4JSCwhdre4tkeUwtDE4o5HK4r0k/sfixCyiMpUd+cImFKJqCtKn3MGAMYaJSrYY2YWhIJMzzksIuBKAy1b5oixHUVEhK2ExhhrTGCMsWEYGhOGJrROdLjw4Na232yhSE8UCQxBLNLAhOvhMBDcWF/fv3+fMWYwGLI7BcxhEIShYWbLNgzDRqP5qd/69JlTJ5sL+wwqEBIkVyNObMGIESJUwH0YdJGVoI7TJpw57onryQbiyGY6kV2Eh6XJqHPuRlVXhkxQJZUqLuYbE6xQegPYsmGrgGys7JjZhByEobHGhGEwDJyMDmxoQhOjTLk7HOy4/MqLL7rkhy+/NOH7bbBzIMsi8ta3HTn8yonjr9x559uttd1ODwCMMUEQOqXKzINgODU19Vdf/OJ9932r1po2wwG2J219UhFC2BGx1J7BsAaba8KhIp/8CTvoUDhEIBBTZrQ5EnFVRBQqOpmICKUDpGM8K0g5o9YBurKh5EIwN06yEIhERzoMw1gccxAYImo2GnW/oZXveTXP90kRyKgfogiAsf1a7aaP//oVC4tzQTAd2ONBuPyOO2/7xf/nv33mMyz8xjfesbmxPRgMur1uaIxhw8IMElrTbDafffbZP/zcZ3WtZUHbIODNMxqY+lt22FWCNHu5BAzLzwsHVJuW1j5ZPWlNHxARuLr/Wg47J7nWXKUlQ+noXWXA0AX2SakohhK/jUm4J5swzqZWObSh41YictQ3IQPAoUOHzp5dtmytscbaMAyHQWAio8HGsQUR4T37L7zzTz5/5uEH19fXd1x9zflvuO0PPvsH99zzxXfc+c5LL7l0aWkJES3zoZdf2NjYABBrWUR83//cH36u3+/VmpOhACBaE/DSy0TEZlirN9RFP8mrLwdrzyCgN7Vf6jth+W8sB6i8VGPbXBQzSnNk/cBRuWdV+0GdwMurg1yYaocZKUBrRek8+rQqyWItG2NMaBCVk9HDMJicnPzd3/udb37j71ApiYw5BTmXLmIfOz+38I53vuu1N9zYurJ1fHX1dz70i9976IEbb7j5X3zs46urq6EJh0Hwmc985oH77zPGZsqJifxG2whFUTTSEoaMghxMHHhbd/I6+tGf2O6yElK7bzEByPIPBZRiS5CUgiRriZqMgJVsm7qMXM3JkIQOekyPmjKgHyTuG8i4koUM/NlyGIZhaBCjED5bOxgMiDxEatQnrDGAgEBRPX7UVlUYo4Z8K6vrf/pHn/3TP/qsu2yt1vjABz74/vf/0yAIOt1uu9W65557/vE7f+/XWj55o6pv0ohgEQXVCDouCMK+8uG8d9DqMfvCFy1LvT0F+3+Czj4ZLD+hiNAOy2O2UXFJ+ryWp6WKekuXxfghHf3LFZYyMzBHOpclV7JbrLdGUNaKCa217Iq9LVtjrOdbIhJRRATaSwJ7lGqAp+IXXr3G7Gutf+anf2r/+fuvvPI1i4uLaxvrwyAwYYgEL774IpEm7TlPBwEsekBq1MrXtc0EAGBAGkpoH/wdvzU93DhM3Gle8lOD2kX09L8z/SVUfhUQKWqngFys+intt5dDk2ZOfVIhW3YniLshx+mVsohHtsUhAIq1NgyNMQYRjTEiElrDzElFARGk+01mjCQRAbJIFmyr1XrXu9/drDe3trZOnzktAkEYhGEY5ysQEJm0K58HVHFrH4qiLc5DJRIQQM90nrPbSkSmdl/HB34ZzjwaHPlbUYTWFHM0iaJyfYleTSO1HPPptA0Ya09OujxnjBsXTCEARcwsJGnrsljcmuCjnYwOwzBxWBzpmfMw9ZLoHaJFJUgACFQ/u7zSbDWHw6HbszAMg8BoHTVnZlKuRIQjblGCyAiEwBKFezEilxA1ENCabZq4nPssz/73oL+EykMYYrZpRLppgKQLA2LowXgseq6GBUpDlHnVGHUzYRBAIpCStGyhzgCYOQiD0ISxfhDL1towl3nIUdyhNy2SY0ImD/y6FRkOBqGxYRiGYeDsk14XrQCgRqCo8Xd0MlCUL1i3rNEbig1QAG3ogi4gbAXQr2++8DX/9I9M5xiRRmupAuJSdH1d4Xxp7DORJEnGitI1CsUOKfmASiRlLdGoVr4y0RcX2lprLLOx1ljrXEHnZ1epkaTFMhMwKhJE7YGugz8ZWu73e/1+v9/vDwbDIAh6w7AzGFoWIA+AHDZJEBmAtOKhfuN7fvGP7/1LnLoQyQfU4mnwfFFaiARRhEBxf+slFodDdqmQkuB4KiIfZxMQqGDalmUOBbEARK+Q5XG1CAAIq4S5x/9IkjAUZx0nlQDGWGs5rhEvQ5KgGCAGBQCilKgaSA1b8/0AtBkOgjApZRwa9n3PzXoAcaW/iGJB+2HAE4t7Fw4cePLICoDPSqHnM89CAKC6ItuEATipomrMjMDkWuzHGMZ8PDIlPsAdVUKsaAycbUIjJUGlYo1RuuhGREislBjz5diwpMozDMMYss/OVy4tZIvMcKdxWIkiqz1QNfDmmrsut8EwDAahiXKt0f5xjZkBkTWyFQREr24Gw8X9F19+/Q1f/dwf98+uUK2vPN8O/IN3v/fdd93yrz/5n+zpxwGAwBAIWBv1u4gq+aCigSyCCKamayRWRw6Lk65YjuAG4/GTmVvGAjeappDa9mp8HwuwNRwOA2ssIDJHSFQH94fCQeNoToZGVKCJlRLlk2qo+QPNHXv7nVUBFGtdnyBrLTrIJTMoRAEkFNJ2YC655nWL+/Y99Pf/e9jb9uq+MYqtTJ//mitvet3M3AICAWkUEbQoIoTCgqlFpB4pTRZOEp8QQ+aiuB6Mg5LmMyylaOUUjinCMET5IeZi1VthzyK0aBiGxhiJ4Azgfk0jEtJLjAQOEpPHqgZey6qpqYtvGqy9Mhh4nl9n6zIwI+QqEgIqUHUbBoh43R1vIaw9+HdfB7Dk63Bo0POuuOn25szOv/ovn/3z7T4OTyAAayLREopIENl/1SYaIrlWLkkXiGQ4SDpFV+rEIaIeA5YtIphiKkcZSsHyTG5ugAILG7bGmhRw36SLNtKWBiFY1AAkCpgU6DpgrbnvmskLD2x9/at0440AYoWjFpCAFgiVj14dvVoQBtM7Fi+/4ebjJ5ZPPPE9ailg4qHMXXDg4utuWllee/ab96DtesozwoAoULchgGcosGCNgAXgpKtUGlc0ojVELThTrcPO3RjXdfg7hxlY7HiA2WZTYwYTuCu4YHycs4pieGFo8jsvzp7TQh6TZqyBaqE/Ae3dO+/4JxsvPMbdFdKEIoSotQKt0fO0rk1MTKKwhHzhwVsPvOGOZ546vBY0rnr7e7m2oP2pA7fevevgO77/+KlDP3hAQR8htDIkBLa16QOvf/fHPtlYuKTUE86hLlL6sLLWegwGmqqgM1mwBybp7KisIO58ML61TmJmjAKkll0G1r0GJACxDjeGYFAJKUIQpayqSX3CSuv8t77TMPafvl8wBCFGBCJUmqhWr0/Mz868cuTYVuBf89b3+F79B1/7262e/pV/+cu//elfm77otktv/ZmVnj52eu3//fe/NHfNzWI9EM39AAR2XHLwx9/zU7/6kZ9uTi+Ki/0DJdAtKM1iOcs/Y4OUa6lKF7yqrihTBxfXSiR4bKkQZzlEehLsBwDLxsnXKP3qWuKBAIAFFEJRYFGL8lWtZW1r9xt/YuL8gy//5f8Q6HuNnSFjvV7nkLXvTTRq3U7vW488e2i1U9+17/CTj28vr59/w00XXXv1P3z70Nf+4QzK4OkffGN6cc8td73pyisu1PUGG6Oarb0XXzm39+LewP7vz3/+nj/9Cz77HClgw+eEmMbdXEoABaV5wjwQvcqvKylAAyGwFpFlJKHK4HqZCpT0zAIBYFHWmriiL4oHMmmLWiEBKFFtqLWsndp964/tvOO9L33l6+HGIW9mH9pVAq77rekJ7PaCR5458aOljvUbnfVjx599tr173xve91Zr8bknj213j3eWX243g+tvf53fXrzvi1/6+u/9MdXCvVfftLDv0s7GyvOPPdxfP+kQ68Qhc+Da5JQ5AhkcALAVFBS2AqXNQ3KFPEmJiR4TahjZdoBReQQgA7GxGIcLSy3oHBI3sTGYxVpxAjsIwrhXLlpAiwpJMXmia+C1rbT3vekte3/yA89+7R8HRx9pXXDDcPml4dJTi3M/JoxPHV57+Iwdst9bXzrx3HNqcv6ad/xUu90+cXRt6dRps/ZKY6r5mptubO887+XHHz/75N96E/VLL7546vwrj6zQY488Cusvgt0khcAhihHLKIDCCDad1QZIw8YTSw/BsqTqteIGuFV57bgjeunYnxKMx+h25IAEnK3HGtMEzvf9druNSMziCxtjYCitiRZoBNBCvoAVUqI06pboCVubu/Rtd87eevezX/1u//kfTO66dLB5vH/myQZNPfri9otB48wm8ubS8tOPhqguuPHW+X0Xbax2XnjomeHqsfaEv+/6G9vze04fO/L0t76ha3DZDa+ZmJtbOrV56IdHPvmbv3T2yCX/41O/TYqstcAW2DAIMhBbQE7nHHIQpFFoXzjqW11R55A7xO59XYqeOUfNcKpbdFW8P/2IL730Urfb7Xa7WmsRMcYaa9utxvr6OvoNJi1UA61F1S1O6pl9B9/3c3r/Nc/+9d/z1lLrgis7L94/OHvIv+DHZi+/9sH+5nD58MpzT5lQdl7/prnd52+eXv7ht+43vbXW3NR519xQm9p19sThF3/wv2p1uvSaa5stf/n06SMvPjG7+/yLr7tma9A7fXadCdCFTEc8xMnEhCosHYzmVGF1jUx5kxMRSfpHwxhjUKI6CrLDwezey2Tfm1e+/ycelQ+eyaKQRYQ7nQ5ImK5kdaF5qk1Ra5oRyWtaNSk4tePg6y571zvXVurHvvtQE4bWDDZPHvJmpnccODjRlOHxJ5aff5ZDmbv8ponFnZtnjq4cOWK2z87O1CYW9kh9Znlps3v8pK6b3Xv3eDRcXznT6/ZnF/bu2LV/feXE8onDw64FMYQbEnbBhmiGKIZFwFriEKIWnqUhm1h26Nbk4oHB2WeYWWtNpKJS1erYNCIyW11VIZMl3Ei/YoI7q4ivFmwPaDSbABB3hXVtvRXoGpNmXUdVN9zUi1ccuOttc1ff+PLjx1Yff8qDsG+2kfz5m9/dqEP/6EPHj75M2Ji77C3e5OT6yUOnH/iWCrqTE832gSut0KmTxwcrL81cd8sv/9r7vvTlx5ee/EeU/uzs4sz5e89smJOPPQH9V8Bsae0DaaN2QOsC6J7E3mmxNp65AGNwm5n+qHFHZYuAIITjYBoJrXUpq1eV6wOAZQvVrePyCP4khE0Owa2EPEASUqJ8UT5zS7X2XPSWH99/x5s2O/qJrz07PHWq0TD1ySlv+rJ+r985/Nj29tn61OLcZW+yYjZOH+4993DNU/Ozbe0vdLa2j7z0Egzt1AUXHLj1jj1XXHjw4EX3/t2PWrPnA5jl1ZPDtZd/9lc/eP7E7b/9id+UYMUMBVuz173z/Z/6+N0ffN8nzz6xpM41XaRoTEctwTFyY0pLuwotokCPNRvTHSYiMLqgIHFkcxBiNorI4CrxEQAskkWFLEgARACKlRJVF1IMHnBTTy9ecPNte2+7PWzOP/e9o+uHTk9O2h0Xz7PyO53h5vNP6KDXnFnQU7uCzurZwz+SYb/R8ncsztnhYG3l7HD7qJrZuffK6/fsXSCFm9vDh7/53N9/5TE5+wwPNlqt5iWvvVzt2FurwfJmAI3pHfOzE+0ZbC0Eg/Bv/ubB3sYyoXVsjMIQTT2AgvxNvSnJGNiYjhGYHqv4dRSSLpXRObhNEqS3xkwt7PEuuvPUD76geZty5UcRQhsYUFC5KbUAWohYe0i+FY/BB3+6tWvfvtfduPvG67re/InnNrZePtP2bWOuHnR6W+v94Xa37uua32TbG26eMd1NBaHvaeBg2Fnd3lgDRdO7L9p90eXt2elhp7t6cmlzdWvQWSYe1Go4szgzOz9jQ1hZX1tbXuv3oTW9MDelZNDvrB7bWDnOQwsBIG2RdNgyWEYOFdjCANc8oYUNejPthf3BynMWEDVpIEWqavJdps6wNHGVK3tP163boNPQHtSmod+xggQMIOza6DrWJRISQI+RGIlBW9QANdCT3ty+8y67dvfBK6YuuGC9o1883OufPd7Sw4WdzfWVzbXDa0Sq1Wq36g3T3+6tH7PBwNNY82DQXd1eWhVGPXve3huumj3vYr9W21jrH3rqaGdlSYIzvpKZpt+YXtRa+tsbLxx9xbKq11q+btcaPdk+fOLYst0+DTJAV4fnWQmsRO6TCDBDGnmOKXsu08KftCa2zIykSEaVnePniiEWHJZimVQGeQZg+x0kxtYc906J8kVCEmZQQgREAmAFBTSzYvTFn6b2fHt+cfbSy2cvvnJ6/3lcn9haC158djvc7pFh32ytrQ2NrdUatZn5NgZh2N3e6iyZ3haFHeltbHU32Ro1tTh/7esWL7ygMT3Z6/bPHFnePPm03TjpYa/hqfrMJAJzEKwcP2KGA/Jqym9o3R5YuOy112ycPvbKA48TdDSGwCLhABDAYR8QEAwgYx5eBGUGKwEAem3gkG1IpCoBtGUSWKf7tFX1nIZUj8JhGKrhWTVx3nDtOdQ+snIzIZg8VB7oGvo79MROf/a85q797b0XtHbu9qanlFcb9MJTR7u9zRMc9MKeCQYchujpWnNqwYMw7G12T58Zbp4Kt89Cbx24g7VmfW7f3mtvnL9gT601zf1g+eipo0/+qLt8yrPbNc/z23WgRhAOt9ZWAxsoVPVas95o+R7X6n5teppb05/4Z2976IGnf//b9yovEBMkEy+IgREQGA0LMKV6ZWSLo1KaTUQAlKpb2xXAKOZB49ImGY/Ryeiq+F7SpDZ5LzDD3Ze+bqt909rxh8HzEDXVWroxS40Z1Zz2JuZ1exGac6o1QXUPwmEY9sPeIOx2relZQWZS5Puq5vmoILSD7eH6mf7y4bC/Rhwo3/MnFhtze2huX21yJ6Bve+v95SP9tfVw4wzysOZpj0ILHpuhMSFobNRrzUatVtOeZ9AGHPQk7A66W52t7V43gOl93FuzZ18k2wcOBcQKIhtyTSCioj7GfCsHKEI7WBhAtxcv597xQWdLe15ceK3GuCCj5lWl827Lq7KiwdvUXTvW2PVm8acl3EDPZ1FsDA4GgEOwm7Q9BDxDSMwWENHzSBNoUlTzNSlllO0E2xvd9bPhoCtmQErXWhMTC/v0xCLVJ8CrGWM6m931o4/arbNgBp4mxYOGz4Aeki9eq1nztO83agoplLAXbK91V1b6m+u9zRXT34KgD2iBCEjBxgnFAYEBcfkCQbLEQTIHDTMwB86VxWfCOMxUn1a+DtY6qY6tcs6R2XmkUikSMpsrcYFTFWyttvuv+K35wcoZIsVGsViygdgB+ZvoTWJtgrSvPE+0RmSxzOHAmMEwGDicJ6Gn6wvehKe0QvKthZ7p29VlDo6CHaIYhYpY/JrG9hwqpT3tN5ue5yEJ2a70N7obSxsnlwbrp0xnA4YdkACAkIwCEY0oKMDAgihRuJvZAhBYtAYT+ZBpSyLnQoiz19wBwaYJA1J+MluptG9EMaWnq1y7qry4IhoMh+HykxMLbzEnt5l7aLbQb4PMIiIRi6DYgFFZVK6luDCChKA8QlSuQRqBMV0ZsrABEwIp8uukmt7EnPI0KSLQStXBE7Y9FfbBdIfrR7c3zoSbp8P+hgy2gQ1gACAkjCpEBgEDHCBbAAS2CWtKhHVGEqMkdGk/gtFI3fGWWUwoRt2otZrh1mEBotQ41jExokrz7pxjs6P3ye+debm5sLo9vd8sPYy6JqhFL4vXtKpG/hTVpqE+qWqTqtYk3QTtkfaJPASxAiAKFTIIKgWsGBgQFAAKCQRsejzohf1NG3Rtd9X2ViDo8nAAPAQISQKMELQW7dAlDpAtg0UBYRv5x8II6Ao7BIEEASyCEYk6/+TyFmPGpTr8KbDRzX1KwmFvm0i5qt4CCFSqcR2gixOfAWC8BU4EvX6/febx1s7bNpd+hGZIaISNhNuCCvC0RQ2gjKqxrgHVRddR+4ge6Tr6NUQPSBMRALMREQYO0XSt6dmgB2EAHIKEyCEiCyCy9USshMCWxDCwsEU3r4GARJDFYq68PKrRQwDFAGIADGT7PyWNDM79wwLUqk8u2K3DgbGe5+cyLBXFmVm4QbEhLpxrgK6ICOqN089Mzl403PP64ctfR7+J1oBCABJUSChAxF1lfEsEogFBgJhUBGVHFesccrl1jEY9GjdZDNmAuDEi1qHQEIRd7FjAvSkQzy8UUeysghj7FIHGXURfBAwAEIzGc1oAPFckKOkCAcZ4O/Zp3ux215AUlPXoL7a3ycoT1LkJG1VHKaNMAYmgH7D/yn3TF929sn7Arj0HflvYIjCCRSuILoM7FCIRBeRy9YSADuSZUu0OcO1oY125nLO6AARdfY4YAFHCEI8mA+dtCBq0IDiapyqMIMgRrEwAc1DxUU76XH5ztFYbqvZ8a2JyuPJsaMHzqNj4slQM5Iy38spZ9+PSernxF8nnlfK211amG/e1Lnrj5mAN+6dJtUVY4lbNDADIyCgiilCAJNYhnHGO4vF1IABI8Zl37EcSob9cpEyYURLXmGPFLygSlfdEzB6F2VzSviRGXDEqJN+7Aox4E62Z/bZ7bNDrKU0JDmyMMVca/lT1eqtol5SWFhWn5QhSsLXa9kXtvi1cP4HBKhGhWAcFi0LlbCOxIExuRItYFEtiiC2KBWGK3mQSi8IglphRGMUCWxRG4STz7ky2JCiuxJIIikVgYJvtxp1CJlaOesaK6QwIYgDrrfkDaFc6a6eQlFIeEbluZ7mBNUVOzaH3VKPRhmwf2OJYoqpj5VBU4daZyZaC894wXF/C4Qop7YrTlWteBs77GjVIQSczGRlTtqfrHOBgZlHnklQBWmQnRBchYBRLwAgsbrIOjDpzpzMjdI4lAJT3RiMQg9RoLFxRh+3e6hErSKSIdFyETKVUKg4oS15Es7JeJVCh+D4SMsNg40RLG2/frUEo3DmJAMrNH3USE0Q5g1cEwaBYAEFkiurn4rlwqcGaAFGjCpSoVguFERmFyWlIsAguiJxJkeXGMsI5NB6WNIoAsRwqf6a1cMCDje2VV1hIae2q/whdCy5VHC5U7OufJlee0KUBbChrXY+pubPMONw47fNaY89BaJ4fds4a0yEkiApsgAAIgWL5SiBufDSCRbEork6DEUSJIbFuDhSBIFsCATAIkQBJjdYYdZjN8FiujcC5ykwyjM1GRPsT+9o7zoPwTPfsMRZQnssNIjh3q2ws0PhwBwCoWr05Jlw3Hsc0Gk0LIKiGnTXVOdyaWcDF11qsw3ADwj4Ixxokit/iKB0Tj4uKumBZdwIAhEBAhACS4dqJw0vp/KXzGlzhXNR8JupXQpGCjSaTS+InZrwMN2DcZaQsA+rmQn3+knajbrZe6ayfFSSlfSKFruW3KyLPms9jPY9RJASnZxaqItal9YdFwZ9G6RljPJT69JxaeE1Is4ONpXDjMPdXyAwATHYyNthU87m4eBOTVgIwaqjgPokqnlMfN+McsQIlsZjRiIrR2IJRMWYMg3X7jIDsqhBVzavP+q0dnk88OD3YWB4GJu74phHREhCQShWdFMe9lTmWo7k2ODU9n/2QZHRCNWtXjKgRyyzGKBK/vUOmzvfqO4xVwbArQdcOO2z7IhxNYI+GoaNEToZ1Qhoh21k6KhaBeKZy3NQBjUt6ADDGChORXN9igZzZCvFYDifWFRGh8kg3yfM9j7SEdrAebK8MwwBIJR21stK2pKSwKjPrbC6KW9dFhIbMHHVIX3e881Jk/7iNoxXDgOL5yqvNUGMa6hOi6uDy7q5bSsSEHKU7o9pFABAkiq1xy2wJVTzaUxxXR04NcETDGA9AqJBI2HJkZceYuRHch11LAGEGsWJ7POxx0AuDrrEWIeoQmTRTy6q7pMMajMdEJ1CxBPqCU9NzWViqlGJVi748VI+4iBr8SOT1CLuBkuz6tqZkZWRlpMHHmYMSF0WP5qkXKgDTI+nH1e4V0UXi5pG7DqsIiEoREjGCQqSRfY3FadJlJnMSDUQomw+lqwgXz2OXYsi12OKjrLtKtPGICKCjVoSJQZ1IUIxbume79kVdT5FGBMo2AIlg6xhhuUadpCTnpkQpfERKRHcU20MArRREzr97M+q4J2kpXNqPpyg3pNhTPc2XOiFobmBTqjkwVGFNq/1XTA0DlihXpDDuK5bZ8LxjpnKtXEQEhFBAiKOTm9SHYVwkizxmjITKWXGWiSkySxQgAlpgRKWSvaS0OJYCOg7SvRqLKLhSAasLFyq18DOsnWvtVtXqOwXMHD10/Plcg6C0gZC0/UxldqI5CRC386eY0STyhVXJZuNoKmjaGAVFQNl6boI0dBFzK81axJTpEl+okC2NYbigUkmLPCwJeEG1kMExRc45jyH5Nbcf8Wako96jp8esykhsufQ3KtQ1ZlmMYss9bpPk8nNA2QZSlSG9hJGLab/SeUSZgs70VUrHRGVly6tyh6DYTb2s10Lp0G7IjiZ+FYW9mecvXMeNfUlVvsqof/CoqwJUzX2TnEQdEzyperYMyHE8tONVdk0YnxaqshErTtI57ScoTYwWMhhUtbvnvFdVAqUCpixV4EUALHHBxzjs/8fUrwqkjPm1NEZT9WxVoZhSxVPMJY1J3VWV54wha6mxQFCYFD9+AOuYMcWlYqvKpy9uUq5zXjHaW8pxY8Y+pxefLlsqUrl0iHShWzC+GmYq7RRe3t2gKu5Ruu3njD1BxRjW0iNZDBaWZiuKIqjoIBRTGVVcP2ZIXu6O4zVKBdfHhk3a2ynNqpQV0mJVWd14zVCkQo4FIDXouarStGp3x0jt9AWr5p2O0WPjr1klAHMsReNvM35KOZQVjuf+WjZeF8czfpXkqSxeqmbS4j69uu7C4zMyOOZh4htxbj4JjUF0JAXGOX6vms89RnqOn0oP55h2cw51N2bLS1XO+INVJEjVWnKDwbLbmYTkIhNTj7fGoKL3//hqryqra7xxlnN2So3iIo1e/W4VuT7XV3tcmVCZrqpab5mrLP8/TWnnZ+xUY5wAAAAASUVORK5CYII=" alt="HF Connect" style={{ width: "100%", height: "100%", objectFit: "cover", borderRadius: 14 }} /></div>
            <div>
              <div style={{ fontSize: 20, fontWeight: 900, letterSpacing: "-0.02em" }}>HF Connect</div>
              <div style={{ fontSize: 11, color: "rgba(186,230,253,0.7)", fontWeight: 500 }}>Fibra • Câmeras • Starlink • Wi‑Fi</div>
            </div>
          </a>
          <nav style={{ display: "flex", gap: 32, fontSize: 14, fontWeight: 500 }}>
            {[["Serviços","#servicos"],["Soluções","#solucoes"],["Como funciona","#processo"],["Contato","#contato"]].map(([l,h]) => (
              <a key={l} href={h} style={{ color: "#94a3b8", textDecoration: "none" }}
                onMouseOver={e => e.target.style.color="#7dd3fc"}
                onMouseOut={e => e.target.style.color="#94a3b8"}>{l}</a>
            ))}
          </nav>
          <a href={whatsappLink} target="_blank" rel="noreferrer" style={styles.btn}>Orçamento</a>
        </div>
      </header>

      <main id="topo" style={{ position: "relative", zIndex: 10 }}>

        {/* HERO */}
        <section style={{ padding: "80px 24px", maxWidth: 1280, margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 64, alignItems: "center" }}>
          <motion.div initial={{ opacity: 0, y: 28 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }}>
            <div style={{ display: "inline-flex", alignItems: "center", gap: 8, borderRadius: 999, border: "1px solid rgba(125,211,252,0.2)", background: "rgba(125,211,252,0.1)", padding: "8px 16px", fontSize: 13, fontWeight: 600, color: "#e0f2fe", marginBottom: 24 }}>
              ✨ Infraestrutura inteligente para internet, rede e segurança
            </div>
            <h1 style={{ fontSize: "clamp(2.2rem,5vw,4rem)", fontWeight: 900, lineHeight: 1.02, letterSpacing: "-0.03em", marginBottom: 24 }}>
              Conexão forte, câmeras seguras e rede bem feita.
            </h1>
            <p style={{ fontSize: 18, lineHeight: 1.8, color: "#94a3b8", maxWidth: 520, marginBottom: 32 }}>
              A <strong style={{ color: "#7dd3fc" }}>HF Connect</strong> cuida da sua infraestrutura de ponta a ponta: fibra óptica, Starlink, Wi‑Fi, redes cabeadas e CFTV para casas, empresas e propriedades rurais.
            </p>
            <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
              <a href={whatsappLink} target="_blank" rel="noreferrer" style={styles.btn}>Solicitar orçamento →</a>
              <a href="#servicos" style={styles.btnOutline}>Conhecer serviços</a>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 12, marginTop: 40, maxWidth: 480 }}>
              {[{value:"360°",label:"Soluções",text:"rede, internet e segurança"},{value:"Rural",label:"Atendimento",text:"casas, empresas e fazendas"},{value:"Pro",label:"Foco",text:"organização e estabilidade"}].map(s => (
                <div key={s.label} style={{ borderRadius: 20, border: "1px solid rgba(255,255,255,0.08)", background: "rgba(255,255,255,0.04)", padding: 16 }}>
                  <div style={{ fontSize: 24, fontWeight: 900, color: "#7dd3fc" }}>{s.value}</div>
                  <div style={{ fontSize: 10, textTransform: "uppercase", letterSpacing: "0.2em", color: "#64748b", marginTop: 4 }}>{s.label}</div>
                  <div style={{ fontSize: 12, color: "#94a3b8", marginTop: 8 }}>{s.text}</div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Panel */}
          <motion.div initial={{ opacity: 0, scale: 0.94, y: 18 }} animate={{ opacity: 1, scale: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.1 }}>
            <div style={{ borderRadius: 36, border: "1px solid rgba(125,211,252,0.15)", background: "rgba(15,23,42,0.6)", padding: 4, boxShadow: "0 32px 80px rgba(0,0,0,0.5)", backdropFilter: "blur(24px)" }}>
              <div style={{ borderRadius: 32, border: "1px solid rgba(255,255,255,0.08)", background: "#081827", padding: 24 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
                  <div>
                    <div style={{ fontSize: 12, color: "#64748b" }}>Painel HF Connect</div>
                    <div style={{ fontSize: 20, fontWeight: 900 }}>Diagnóstico da estrutura</div>
                  </div>
                  <div style={{ background: "rgba(52,211,153,0.1)", color: "#6ee7b7", fontWeight: 700, fontSize: 13, padding: "8px 14px", borderRadius: 12 }}>● Online</div>
                </div>
                {[
                  { emoji: "🛰️", title: "Starlink", badge: "Especialidade", text: "Instalação, configuração e otimização para máxima performance.", points: ["Alinhamento preciso","Rede otimizada","Zona rural"] },
                  { emoji: "📷", title: "Câmeras", badge: "Destaque", text: "Monitoramento com acesso remoto e gravação segura.", points: ["Alta definição","Visão noturna","App no celular"] },
                  { emoji: "🚜", title: "Zona Rural", badge: "Foco", text: "Conectividade para fazendas, sítios e chácaras.", points: ["Longo alcance","Estabilidade","Ideal para o campo"] },
                ].map(card => (
                  <div key={card.title} style={{ borderRadius: 20, border: "1px solid rgba(125,211,252,0.1)", background: "rgba(255,255,255,0.04)", padding: 16, marginBottom: 12 }}>
                    <div style={{ display: "flex", gap: 14 }}>
                      <div style={{ width: 48, height: 48, flexShrink: 0, borderRadius: 14, background: "rgba(56,189,248,0.1)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22 }}>{card.emoji}</div>
                      <div style={{ flex: 1 }}>
                        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                          <span style={{ fontWeight: 900, fontSize: 15 }}>{card.title}</span>
                          <span style={{ background: "rgba(56,189,248,0.1)", color: "#7dd3fc", fontSize: 10, fontWeight: 900, padding: "3px 8px", borderRadius: 999 }}>{card.badge}</span>
                        </div>
                        <p style={{ fontSize: 12, color: "#94a3b8", lineHeight: 1.6, marginBottom: 8 }}>{card.text}</p>
                        <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                          {card.points.map(p => <span key={p} style={{ fontSize: 10, fontWeight: 700, color: "#7dd3fc", background: "rgba(15,23,42,0.6)", border: "1px solid rgba(125,211,252,0.15)", borderRadius: 999, padding: "3px 8px" }}>✓ {p}</span>)}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                <div style={{ borderRadius: 18, border: "1px solid rgba(125,211,252,0.1)", background: "rgba(56,189,248,0.08)", padding: 18, marginTop: 4 }}>
                  <div style={{ display: "flex", gap: 14, alignItems: "flex-start" }}>
                    <div style={{ width: 40, height: 40, flexShrink: 0, borderRadius: 12, background: "#38bdf8", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18 }}>🛡️</div>
                    <div>
                      <div style={{ fontWeight: 900, color: "#e0f2fe", marginBottom: 4 }}>Instalação preparada para o uso real</div>
                      <div style={{ fontSize: 12, color: "#94a3b8", lineHeight: 1.6 }}>Menos improviso, mais estabilidade, segurança e facilidade para manutenção futura.</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </section>

        {/* SERVIÇOS */}
        <section id="servicos" style={{ maxWidth: 1280, margin: "0 auto", padding: "80px 24px" }}>
          <FadeUp>
            <div style={{ maxWidth: 640, marginBottom: 48 }}>
              <p style={styles.sectionEyebrow}>Serviços</p>
              <h2 style={styles.sectionTitle}>Soluções técnicas para conectar, proteger e organizar</h2>
              <p style={styles.sectionDesc}>Da instalação simples à estrutura completa, a HF Connect entrega uma solução pensada para estabilidade, segurança e facilidade de uso.</p>
            </div>
          </FadeUp>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 20 }}>
            {services.map((s, i) => (
              <FadeUp key={s.title} delay={i * 0.05}>
                <div style={styles.card}
                  onMouseOver={e => { e.currentTarget.style.borderColor = "rgba(125,211,252,0.3)"; e.currentTarget.style.transform = "translateY(-4px)"; }}
                  onMouseOut={e => { e.currentTarget.style.borderColor = "rgba(125,211,252,0.1)"; e.currentTarget.style.transform = "translateY(0)"; }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
                    <div style={{ width: 50, height: 50, borderRadius: 14, background: "rgba(56,189,248,0.08)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, border: "1px solid rgba(125,211,252,0.1)" }}>{s.emoji}</div>
                    <span style={{ color: "#475569", fontSize: 20 }}>›</span>
                  </div>
                  <h3 style={{ fontSize: 19, fontWeight: 900, marginBottom: 10 }}>{s.title}</h3>
                  <p style={{ fontSize: 14, color: "#94a3b8", lineHeight: 1.7, marginBottom: 16 }}>{s.description}</p>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                    {s.points.map(p => <span key={p} style={{ borderRadius: 999, border: "1px solid rgba(125,211,252,0.15)", background: "rgba(56,189,248,0.08)", padding: "4px 12px", fontSize: 11, fontWeight: 700, color: "#7dd3fc" }}>{p}</span>)}
                  </div>
                </div>
              </FadeUp>
            ))}
          </div>
        </section>

        {/* SEGMENTOS */}
        <section id="solucoes" style={{ borderTop: "1px solid rgba(255,255,255,0.07)", borderBottom: "1px solid rgba(255,255,255,0.07)", background: "rgba(255,255,255,0.02)", padding: "80px 24px" }}>
          <div style={{ maxWidth: 1280, margin: "0 auto" }}>
            <FadeUp>
              <div style={{ maxWidth: 640, marginBottom: 48 }}>
                <p style={styles.sectionEyebrow}>Onde atuamos</p>
                <h2 style={styles.sectionTitle}>Atendimento para casa, empresa e campo</h2>
                <p style={styles.sectionDesc}>A estrutura muda conforme o ambiente. Por isso, a solução precisa ser planejada de acordo com o uso, distância, equipamentos e necessidade de segurança.</p>
              </div>
            </FadeUp>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 24 }}>
              {segments.map((seg, i) => (
                <FadeUp key={seg.title} delay={i * 0.08}>
                  <div style={{ borderRadius: 28, border: "1px solid rgba(255,255,255,0.08)", background: "rgba(7,17,31,0.7)", padding: 28 }}>
                    <div style={{ width: 50, height: 50, borderRadius: 14, background: "#38bdf8", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, marginBottom: 18 }}>{seg.emoji}</div>
                    <h3 style={{ fontSize: 21, fontWeight: 900, marginBottom: 12 }}>{seg.title}</h3>
                    <p style={{ fontSize: 15, color: "#94a3b8", lineHeight: 1.7 }}>{seg.text}</p>
                  </div>
                </FadeUp>
              ))}
            </div>
          </div>
        </section>

        {/* DIFERENCIAIS */}
        <section style={{ maxWidth: 1280, margin: "0 auto", padding: "80px 24px", display: "grid", gridTemplateColumns: "0.9fr 1.1fr", gap: 64, alignItems: "center" }}>
          <FadeUp>
            <div>
              <p style={styles.sectionEyebrow}>Diferenciais</p>
              <h2 style={{ fontSize: "clamp(1.8rem,3.5vw,2.8rem)", fontWeight: 900, letterSpacing: "-0.03em", marginBottom: 20 }}>Não é só instalar. É deixar funcionando bem.</h2>
              <p style={{ fontSize: 17, color: "#94a3b8", lineHeight: 1.8, marginBottom: 32 }}>Uma rede ruim costuma falhar no pior momento. A HF Connect prioriza organização, testes, configuração correta e orientação para você usar tudo com confiança.</p>
              <div style={{ borderRadius: 22, border: "1px solid rgba(125,211,252,0.12)", background: "rgba(56,189,248,0.07)", padding: 22 }}>
                <div style={{ display: "flex", gap: 14 }}>
                  <span style={{ fontSize: 26 }}>🔒</span>
                  <div>
                    <div style={{ fontWeight: 900, color: "#e0f2fe", marginBottom: 6 }}>Mais segurança e menos dor de cabeça</div>
                    <div style={{ fontSize: 13, color: "#94a3b8", lineHeight: 1.6 }}>Câmeras, internet, Wi‑Fi e rede trabalhando juntos, com configuração mais limpa e fácil de manter.</div>
                  </div>
                </div>
              </div>
            </div>
          </FadeUp>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            {benefits.map((b, i) => (
              <FadeUp key={b} delay={i * 0.05}>
                <div style={{ display: "flex", gap: 10, borderRadius: 18, border: "1px solid rgba(255,255,255,0.08)", background: "rgba(255,255,255,0.04)", padding: 16 }}>
                  <span style={{ color: "#38bdf8", flexShrink: 0, marginTop: 2 }}>✓</span>
                  <span style={{ fontSize: 13, color: "#cbd5e1", lineHeight: 1.6 }}>{b}</span>
                </div>
              </FadeUp>
            ))}
          </div>
        </section>

        {/* PROCESSO */}
        <section id="processo" style={{ maxWidth: 1280, margin: "0 auto", padding: "80px 24px" }}>
          <FadeUp>
            <div style={{ maxWidth: 640, marginBottom: 48 }}>
              <p style={styles.sectionEyebrow}>Como funciona</p>
              <h2 style={styles.sectionTitle}>Do orçamento à entrega, com clareza</h2>
              <p style={styles.sectionDesc}>Um fluxo simples para entender sua necessidade, propor a solução certa e entregar a estrutura funcionando.</p>
            </div>
          </FadeUp>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 20 }}>
            {process.map((step, i) => (
              <FadeUp key={step.number} delay={i * 0.07}>
                <div style={styles.card}>
                  <div style={{ fontSize: 44, fontWeight: 900, color: "rgba(56,189,248,0.2)", marginBottom: 14 }}>{step.number}</div>
                  <h3 style={{ fontSize: 16, fontWeight: 900, marginBottom: 10 }}>{step.title}</h3>
                  <p style={{ fontSize: 13, color: "#94a3b8", lineHeight: 1.7 }}>{step.text}</p>
                </div>
              </FadeUp>
            ))}
          </div>
        </section>

        {/* CTA */}
        <section style={{ padding: "80px 24px" }}>
          <div style={{ maxWidth: 1280, margin: "0 auto", borderRadius: 40, border: "1px solid rgba(125,211,252,0.2)", background: "linear-gradient(135deg,#38bdf8,#0ea5e9,#67e8f9)", padding: 2, boxShadow: "0 32px 80px rgba(0,0,0,0.5)" }}>
            <div style={{ borderRadius: 38, background: "#07111f", padding: "56px 48px" }}>
              <div style={{ display: "grid", gridTemplateColumns: "1.2fr 0.8fr", gap: 48, alignItems: "center" }}>
                <div>
                  <div style={{ display: "inline-flex", alignItems: "center", gap: 8, background: "rgba(56,189,248,0.1)", border: "1px solid rgba(125,211,252,0.15)", borderRadius: 999, padding: "8px 16px", fontSize: 13, fontWeight: 700, color: "#e0f2fe", marginBottom: 24 }}>📋 Orçamento personalizado</div>
                  <h2 style={{ fontSize: "clamp(1.8rem,3.5vw,2.8rem)", fontWeight: 900, letterSpacing: "-0.03em", marginBottom: 18 }}>Quer melhorar sua internet, instalar câmeras ou organizar sua rede?</h2>
                  <p style={{ fontSize: 17, color: "#94a3b8", lineHeight: 1.8, maxWidth: 480 }}>Envie uma mensagem contando o que precisa. A HF Connect te orienta no melhor caminho para sua casa, empresa ou fazenda.</p>
                </div>
                <div style={{ borderRadius: 28, border: "1px solid rgba(255,255,255,0.08)", background: "rgba(255,255,255,0.04)", padding: 24 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 12, background: "rgba(0,0,0,0.5)", borderRadius: 16, padding: 16, marginBottom: 20 }}>
                    <span style={{ fontSize: 22 }}>💬</span>
                    <div>
                      <div style={{ fontWeight: 900, fontSize: 14 }}>Atendimento via WhatsApp</div>
                      <div style={{ fontSize: 12, color: "#64748b" }}>Rápido, prático e direto ao ponto</div>
                    </div>
                  </div>
                  <a href={whatsappLink} target="_blank" rel="noreferrer" style={{ ...styles.btn, width: "100%", justifyContent: "center", boxSizing: "border-box", fontSize: 16, padding: "16px" }}>Chamar agora 📱</a>
                  <div style={{ marginTop: 18, display: "flex", flexDirection: "column", gap: 10, fontSize: 13, color: "#94a3b8" }}>
                    <span>📍 Patos de Minas e região</span>
                    <span>🕐 Atendimento com agendamento</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* FOOTER */}
      <footer id="contato" style={{ borderTop: "1px solid rgba(255,255,255,0.08)", background: "#050b14", padding: "48px 24px", position: "relative", zIndex: 10 }}>
        <div style={{ maxWidth: 1280, margin: "0 auto", display: "grid", gridTemplateColumns: "1.1fr 0.9fr 0.8fr", gap: 48 }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20 }}>
              <div style={{ width: 42, height: 42, borderRadius: 12, overflow: "hidden", flexShrink: 0 }}><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHgAAAB4CAIAAAC2BqGFAAABCGlDQ1BJQ0MgUHJvZmlsZQAAeJxjYGA8wQAELAYMDLl5JUVB7k4KEZFRCuwPGBiBEAwSk4sLGHADoKpv1yBqL+viUYcLcKakFicD6Q9ArFIEtBxopAiQLZIOYWuA2EkQtg2IXV5SUAJkB4DYRSFBzkB2CpCtkY7ETkJiJxcUgdT3ANk2uTmlyQh3M/Ck5oUGA2kOIJZhKGYIYnBncAL5H6IkfxEDg8VXBgbmCQixpJkMDNtbGRgkbiHEVBYwMPC3MDBsO48QQ4RJQWJRIliIBYiZ0tIYGD4tZ2DgjWRgEL7AwMAVDQsIHG5TALvNnSEfCNMZchhSgSKeDHkMyQx6QJYRgwGDIYMZAKbWPz9HbOBQAAA5YklEQVR42p29ebRlV3EfXFV7n3PHN/YbutWDWmNrQGMjIYEGkDEfNiApgDHYEOzPxp9xwM5aEMyKk3zOgE2yjOPECcZDbGLzLRtnCYMAx2ADRgMCTQjNQ6tbPfd7/eZ3x3P2rvr+2Oece8bbWnksWvfdd+85Z9euXeOvqrBWqwMAACAiVPyI+6sgAgIARB9EEHHfEhD3LgJAdB1xHwAEBBQQAPcyelNEEBBwdI/oMxjdxX0BBABERAAAiaLPcnxf4ejZKXkmYBYASZYj0f/dnWV0cfcPJM/vntJ9EYVZAAjRLSJelhUhRHTPE9FMEvrI6I7Rq/glsq432sn7KVpj8nlEZAAkBAuE5KgF0Q3EvSMi8UKRkJI7YOauAAiIGNMoIT1EtBRJniH9b+5P7p1k8yJCustGmyvJ7UY3cn8FQIrIJCIZZhIZfYBFQESEiNwXBSTZJ0SybJPbResCFBFI8xhL9AsiAGuRZD/SO8Fpiri9dDuPgALgOIkIWNgtM95N5NSmSmoLE5YFGC01Xr/7FdzaAKKjwsyOv9xFmHlE/ZjNR3SSiJrusu52IiPOjThdoi3METp1UkGAYxaW+Bmi/RIQERvvvoAgxDRJFpwcVhEAYLcHOiUbsIy1IfemiKQZH0cnC2NiccXXU0tJXTB15oBi4RAzZHJOHN0z3OCIVfXY8V9Tki4r29LnI8/alYJU0kuIP4OlhEp+c1ui0xSMl1T+zYQLRASRktsgCoBAXlJlLusoUtyq9EkiylA2S8SIm3MPRkRuGaUcmn4zeRG/KbmtTW7n7lSkmltH8Ua5ZaZXiggAJMIAoqNndTpIQEbPhAkLiCQUQYCIyvGTSfzc0eeJsHS1acLljoX7ihMd6bVlmQ7zYjp+hhybF5mUCEUy189tQHbvS3l5pJdL+Dx12dwDOJmKiNF+MkSfzV4ofW+Ml0rZB5JEPudUbvFApN9k5ljJjUiQe/TUGignFpKfhCtLZYj7TJqdi0yAiDm+Lt08InKPkT706RfJdws6HABAR3seKerMoc4+WaRt0hLGyRAnCotrSFMqJXxLZGupjCpuT2RMwYi46ROQ5vHcF1P2WaW+SaiZOv4QKdgCryT3ylpKI+5M8XW0YToiROHEiUDMqlh6nEtNsarPVFE5tXNUegwL0gZFOLFbqs5N4fyWuwiJUM4pobTMSe6VOxmlvJK2kRIyOmNfpzc2u6oS6pSybY6t0lxcKtFejW2Tlg8J4ySW+jktorQEKJXaFdoiJ7Xy7FXciaySj546Z6cjEkCZ1VF6Usa7jlX6pFTY5a6TFgJFK7C4i+PZs1rKlxyC4rPltLdj9uIdq85KUccmZNFpsTuGOlUcNEYLVZkBRW7KmgFQPExjHqaUZ0ttZERMpESV+VzBE4kFWULlHP/mGC55fiq9TeR6pu5XyoxjJWD+uXMrLN7R3TStuIumYZGVxp+zlAjKrCsdYMhFBRLucR8mopw3l15OVqtJqQCIOLpa0VHpktJCMJHCWWshLeUxTXcRBIjCQEmcJHKUETC6Akf0TbFy8UapmJEguG8RZrdXhJ05JMIsgkCEUYQkxXeJNsKiUkkf98Sbr/C8iqZOhjl0rG3yhkeRrDmdmbaEChZYbFRh5NyzgLAI2ySGAIACnISoYomBCGCZZRQyAASw0Rcik4vQGe+OCsgRAQSR4ohKFIZAQORoSYzCkLhlwCxIiJA4uFDqZCb0SblvUqrkyywFEYmupqNtoog+qV2NVpLjXHfjxC5OGcgZi4eUstaGw4CNAWDPU/Va3at5pFUcj5Qo4BkFmgAltUJEYU4e3roglwBHETJBJHAxImFnWAOIgHVxIEwe2AVORWKvyLp9ZWBx0SG2oWVBRcpDQipTbgmtq9RGlXEV23YYWx2pzUgYOusWZmICiVjIStLEEUdrbNjva4927dq1c/+ByZ0X+9PnWa+NuoHKD8MQkZhZgLVSwABiQTgwjEQuciZWEARRjDWWLZGHiGwCy0KonOVPCNbY0SFlCcMwDoILYsQX1rKTT9aGwsyMACLAYC0EPTPYlO7yYP1kb+3EoN83onDkh+bdk1IdnqJyxu1IiQEQQZyZXYxFVT5mVC2AEvmbRJGcOUnMPOj3pqaaF112cP7KN9HC5Vt92thc7W+uhv1NCfsw7Ik1Is7/ZkIkAGZr2TIqcOQRQGsBhcU6Yc1AIoJiQUbB4mg9CGxZLAvGMiOTmyARJEQBYDYI4mJGAiAEqBteY9ab2FFrT7W5K2sv9E/9cGt1eWBYKSIkYQEcnfKcnZ5WnjFBJdGv8ftxamJmdjGW8SOhgQk/pHR0UT2m2VmR7g+6HsI1r79t383vXpOF40de6Z14jDaOK7OlwNAoOZMwAjJbAGC2IkzRYznfjzmKJAmIhALMooWdWnNP76SIuxQLR5Ev972UqAYBdsI5/j0KskgUb2HypDYr0wda510+NburPjyy/eJ3tpZPGfIUJadZ0oGtdIQvrajSjlJee83MLhRDSAU7RNL+Zc7iFhFS1Ot0ztu966a7fmkwe+3zTz5hX3mgFq4AGEIF5Ln1xfkvSasUZhE2CFFCgpmZrQJ26sdRliXOP0RkFfdrxDPCsYWbvJBERktWeyFA9PnRp1msYRuIKJ68QF94+/zCHjzx3c0j3x+EQI7Y2Uj0GCfFydh0jiK67+yOnZDJVmTM2LSB4k5QziJ2+rjf61538MbL3/bRZ0/0Vp74aqt7WCmPUSVmHbOk02SOVI6qAjGDIAozsxU2GkebIXFwL71DCfHSVEwYLcdxFT5b9N/YiyFA4LBvDOuFg82r3truHuo+8/XOMFRKgXDRms75nOlgdNGpcYSORAlG6juzFfHBKUYhgFkQqdfdvuXHf2LX7R9+5KGH5dDX6ioUrAlLys6TbEZGovUJA1hgEzNL9Ic0E3IkQsBJ5uR4RqK2QGJ34SqHOM0fabEb/yqRQA96Qz3ZuOpnp9vcf+qvetsD8hSIIKp0pqIoH6rcfRFRjWarEOKgQpgpiatmuJlQ9bvd2/+vn1y85Z99/1tf849+s+b7LArYChRIAALAIgzCTijHpi5jkl9w4rWMcyHLwrkYSBVNk30a423noqkCAtonHgQnHglaF7b3XY9rLwRBQEphme2cc0xKPRcRVo1mO51ESNsbqUtAnDfJJEa6ve1rb3j93jd/7Aff/nLr9HdVrcnCie/heMR5MCwMYhE5Mq2EEZ3zx1QmDHLrSWIUCZsXratSgubSOpDNjBUjRNHBZxZUmjBceiqcuGRizxW8/ExoM1H1MSG9YkYQEVS90YpTGJAOdRdTkPGXkVkQcTAc7N696/p3/atHH35YH/0H8lrFxDQAIIRJUlWAAIgZhFEAgQVQQBgs2wpOHMO8uSBZKWuXvj6nXxcpXiLSKjj9hOx8Q3tuITjzPIMa5b/LgrpVEXlEUI1Gy7n5qUxE3vnO6MbYtlLEd/zMJ58+HQTP/K+aVgJWxIIwgDBbEIsICE5KAAA7Nw7EIgiLBbYCDCJsTawhebyuy0iSrHgtAj/S/vTYILJURwGFARVIcPZluvAtOjg72Fom0rkoVtqhq8p5AoBqtSazScIMWUuinQhI2O/1Dt7y4/aCtx5/4M8nZMuKAgmZDbMBYBAL7LwS69bLEgIzoSA4deegEezsD5ZyEqdSi1JlPBR/zaWxczG50gNR+XkAQYXhxrA/bFxwqyw9YSyko4xjYkzuyUeyNwe9cNiBUawle3gRERCtMdMzE4s3vOulx++bGJwy4IOEbC04vFQiniOLl5wXNkqYy8hjxySfJFwkQULlxJxI/s395PapeA7cw6clUqlAL5EqwuA1eenRXqfv734tcBCb4FK6u+nMTprulDt6pXmwtHxEwDAYXHL1zeuDCXvsftEgHAibUZ48l9yOCZom1sg6lhTWIUuytMGQI1/OthvjPlSJ6VKgQVW2SEQU4uDo93juGu371hgZoasklSPHilB4HPQiwiTmGZMLne2QS28jIrPU67W5A3eceulHNbMtFoRN8tzWWmstM7t/AQDFCIcJ7XJazlpbKoWT/Ui+kv6pchzG0724PVXsn98wEdR12HgxGPT0/CUQDkt1cjFzkhYvenziMgccQcRgONx/yYWd5t7+yW81iZkRk+hBwcgtLCRjUXBK+0HB8Uuv3Jl3RSqUcuirEb5F/6WKaqNvYRguP+/NH+ATT2DFZqe98Nz1dfJJGiUoMBWSlkwKHRE4WLjw2s31DeqcMEoRmChMnCVZzjEtmmI5OuYM3iovoxjQyQniMcZfkZ2LhseY5DNRjdcPy84DujFnB9uIOgl5njMxjQm4KytapSrzJiKer1rnXbV1+iVltkmsMFuOtF5uwelTnxMF6T9VpVPTYlrKjkbxnSJsLneLtA6KvQ/JgoSk0rJGRf01HgR6YpfYIE2kYpStmKLVWcO53FVJbmetbbcnuD7bX3uiSS4JMopsVemubBQ8MRNRmMcQrsjXRbttBGEGcJoh3pgkLJponmyODTI+KAIwc06h5WUIgsgw6JxptnaIWHkVqeq0CaZTdkUm/5iK8Y+cbra23poeGJ+6qwIESSK14OCmWJuHgyCKBEVxOAFBa63na6V0In+LRCy1ENIiQinV7/d6vZ6nvfbERLPRGAVScyGtBGg+Qq/LCKku4Pl+vz8YDodKqbIzHQVmeLBmm3uiaG/qeYo4ptz3dRLPSTY569GnMRYgYmvNiTC0tr8BUAg4Zl01ZlaKev3er330Vw9ef32/P1AuLoMIIO2J1u/+5//ywP3fa7WbOXu5+G9OjDruC8Kg1+teftnlb37zm284+No9u3c3m01U6BR+FrwgsfqHJJgzwulaW6vXDx06/J6ffi9Alc2H7HhluA3KB1QiLIIJUNSdNnfTnIpyGXR9TpDGyMQGABbPaw6HAzDbQijCSV1J1sYYBfWt4UsPHLjuuuu73a7neUppIgDkmZnpz//PvwiCoCmNnMlcFS1ympBZPE9tb3dmZ2b+1b/8jbvuumtmepqZjTEAgARKEREppTAiODj7tQhDTYjCIh/4wM+fPbsyNTVtrS2D3Du0BIHpASkk5TZbBJQqR8/kADS6iCZwTF2mFiIAtGUWtoyACNZyVNyRDwyO2L3f6/W63X6/H4YhkSYCJKnV6mEYlMriKmPL7YdSamtr64orrvj9//pfL73k0vX19bW1NSJSWhEqcrmZCJBDREjkFlxCaHfNZrP5sY9//Nvf/ubM7GJC5bxmjuxcFLYu2eEexgU1S7+S8w/1GDhSGm2e7JCjNyEAW4nSNhklmzMVmC0iaM+j4ZCIlAJSBCBOFLLwmOhPUfshQqe7femll37+z/5sZnpmeXnZ8zytdYxzEkQkVCMyIyZQ8CKY2lrbbDa/dM+Xf+93f3dqes5aW8x5jyLISd6MGV4FriOnunQuGVNRlzAKfSARIgALEHBcjDUm9O4gCCN/iSIsrINaCUup6VblXxhjG436Z37nM7Mzs1tbW77vp4mBKiqdq8JRpt9n5nq9fuTIkQ//yq/U6+2cAMy9GGXgkhhNFkKfvkWpJKEsmaRihZIAQqK4uMuix3Zx0aobxTPikCARIbjiOIgxbeXORVW0iIi2t7Z+6Rc/dPVVV21sbHieN4LQxUj67Llkh0ArdX8Q0Vr7C7/woeXl5UazlXPQy5xbcVAIimqxIFnhq4nD6JyvVZanyRwUay1Y68IUkBXlsX5IRwlAmBGdsERS5MRnYrZbtqWeSC7Y6H4dDPq7d+9+1zvftbm5qZRKLN8YwIi5Wp2UNQ0JfsJRyVrbarV/4zd+4zvf+db0zIIxJodiLT9eEKGrMk8LQIVqmmJCS5dX2mVq0yRXggoglq2vwcYJ0zRdspIaWYQIkQRRkEQppZRKYd2iU1EaG0onXJRSnU7nrjvv2rlz5/r6uu/7WdgnAMDs7CwiBkGQrosizDiFiOKofO9X7/30f/xPExM7bOzmjHuGGHgJACxWOElnY1VsK5sSEl0a+srCwlNFiinDn1mAyi2NvH0GnDNsU1BHyanpogWdBvxdf/31TmU50icf00rX6/UvfOEv7r333tNnliB2WRAhl4xHVO67Lx065HtNQBKxuYLRkghqIlslkp+xXSsAwizFMGnOEdelFSVpSzvniouIZY5qSDmpgCvBV0QRDzFIkGCN3Y9bW/wtGB9FS2RLvV7fs3fPcDjMhHqRkVStVvvIRz7yhS/8uUsblRaH5Soy642W5/sitjQUVazNip13zm5eykyoKEGMHJZsqnw8sj9GdIEwWyRMcg1FPZOiHyrSSqmEo5PVMjNIZUop75ix9X2/3Wol8Q0kREIRnpmd+cPP/dEXvvDnU9PzKVmHBV7OE9RJ+XNWimRtD4ytvZH5QFmvrWjhZCpncyD4QoVWYk46k05YRJBgbAwoXmDasM3UygnkMym5iGgi951Dr7R2Il4pTSRKAZE3HA7/8q/+Wqm6c6ByJQel8dVXgbgteaT4wCZyFHK+T2m9LSIQkc7mvKuEdQQ3jCC+ibxOJcrSz50k92LYvSQc7XgxqbkrYgpKgx7uCVhEKdRaCbDS6K7peV5nu7O6uqKUxyy5jgrlVUApFQeRDiDXRyB5mpwdHUdKhFkEbHQlxHQpakW1R7Qgnes+UbXzGctEmB1U4FUEKFwldMLRmaulaDK+aioKwKEoAlJIjEqRI7TWmhTFTT4y53IcKCnKuzIimjAIBl1db9a0LykXLGd1RBAqdGUMLEIg4ppSYApTXRCDcVKxiKEqxJVihYgxYpNUylaHdDg/mxJOwfeFk/x6SraUIJKKHM3MAIwCJFRvtDzPi+RR9EMU10tlhFLG7AFOK5OkzB/Rsm1Mzb3lQ785v/eiYWCEPAZBKBSjJ36ZALIkTJmUmZaad+kQP5WKpzKH2EnlBAoa24csudxSKr48so3igueyiwvkMrClqDhE1Mo7ffp0t9udm5ufmZmJa7kckg0pe5BzK+IE4uBgrCIMKkTPsDTmL95x97+56r3/VvxGSGBpVNteksYUoVQzl6rMd7b0JObo0mxe6msU1dogOpuRjXUaQYQFuOg6OxcgYfD03uZBOc4rj3+cNBgZFYjuTaXUYDBYWjp1151vv/rqq97//vc/+uijO3bMOA/br9W0VuAKUATKEgij88oCloUF2Q49TUrVzxx67Pv/35/Ur797/2vvMIMA0Yth+pCvnHCqjRmFqrLvUvGjqwKpJdIW0gVg5GhdhaMtZqxz5xoAOtvbw8HW2pokYbOqgmcEuPrqq26+5Ra/7j/39FNf+crffOUrX/r0p//jr//6JzY3N3fMzl5//XUvPP+0X5t3dWBpSFCSWXFPGKISIhiEV9/9K3uuev03fv+f07B3+jv/bfamu2du+5D+4f2WLQBSefePCBkgMWirNHNYiujVVfQtqTyN2lOJgBVBOVcZZdIcBwHSxYdODhgT3n77rY16o9VqWWuTJE/yiA6YSkoNB72b3vCG9/zsz8Daqh0OJnfvO3X69Ad/7uc++clf33Xeng+8/33dbue3PvVvz5w5c/+DD0HkEEZWQlpiKASv1hQgJCXKrpmZ2cvuvPgN9z/7zf9pNk8cf+DeuTd9YHLflesvPYYqAmQW1CkCs6uXTDAvpYUtRTSSLmahygqJIV3jxi4NSoKvYntk1Ecps//dbu/DH/7wRz/qMRsno40JjTHWRhKbmYlQWGrN5mB17cn/++fxoQdn5+dPvv1t7Tvf9Y1vfOOWW2/757/2q2964607dswuLC7e++Uv//CJJ7a3t1NhbjDGsLXOHzdh8Ml/8+9PLq36GkzNO37fn+HV75y4/v3+A18ynbXOM19Vt/1846Kb1158REiLCaS4oki8h0m+MUG9ZMBcZXW1uhTqUMyYRelJp2pZkpqUMVR2ux1XoIxo7UoFRGRraysFbLLGGGOMNeJ+j++sGu3+fb/wQbnv/mmlaHllz+ra2VNn2p/4xKc+/am73/72L3/5Kx/96EeWlpaU0tddd60IG2OttdbYMLTGGGYeBsHU5OR/+NR/OHH0aHPXhagb4dYKDFbXH/5S+BMfa++5au2575iVQ52zJ7yFqz3PZ1c1igWlJYCADISADCwusF5WLVsCC8nRd0zVW6TWXYlfDKYuxRUm1lt0UDjzOUdaRwJmFmEHJLPGGhMR3LK11oZBoGu1pUceefnBB57z1SNKnvL102eW5h783tG//utrrrl2dsfCd7/7XWMss4RhuLGxsbq6tra2tra65l5sbGycPbsCwvd86Z4/+IP/XpvaAbUmt+bRr7OE5tTjHUOy41JQnvRWefmEae8nXeeqkEBUUxYnxUdsDuny8VLPRacd7mKng2wld9QEjpCErSt2KYYp8rEOFkQHuuA0LCa2TKwxNgxtGBhH4jAM2SWLWMBa3TKnj7x8lMEQEnMotqb1rmPHt779ndpHPrpnz95XjhztdntO4ET7ZUwYWmuY2QZBoJQ6fvzYb33606o+SbVmaEICIlW3pOzWEnY60N4JSCwhdre4tkeUwtDE4o5HK4r0k/sfixCyiMpUd+cImFKJqCtKn3MGAMYaJSrYY2YWhIJMzzksIuBKAy1b5oixHUVEhK2ExhhrTGCMsWEYGhOGJrROdLjw4Na232yhSE8UCQxBLNLAhOvhMBDcWF/fv3+fMWYwGLI7BcxhEIShYWbLNgzDRqP5qd/69JlTJ5sL+wwqEBIkVyNObMGIESJUwH0YdJGVoI7TJpw57onryQbiyGY6kV2Eh6XJqHPuRlVXhkxQJZUqLuYbE6xQegPYsmGrgGys7JjZhByEobHGhGEwDJyMDmxoQhOjTLk7HOy4/MqLL7rkhy+/NOH7bbBzIMsi8ta3HTn8yonjr9x559uttd1ODwCMMUEQOqXKzINgODU19Vdf/OJ9932r1po2wwG2J219UhFC2BGx1J7BsAaba8KhIp/8CTvoUDhEIBBTZrQ5EnFVRBQqOpmICKUDpGM8K0g5o9YBurKh5EIwN06yEIhERzoMw1gccxAYImo2GnW/oZXveTXP90kRyKgfogiAsf1a7aaP//oVC4tzQTAd2ONBuPyOO2/7xf/nv33mMyz8xjfesbmxPRgMur1uaIxhw8IMElrTbDafffbZP/zcZ3WtZUHbIODNMxqY+lt22FWCNHu5BAzLzwsHVJuW1j5ZPWlNHxARuLr/Wg47J7nWXKUlQ+noXWXA0AX2SakohhK/jUm4J5swzqZWObSh41YictQ3IQPAoUOHzp5dtmytscbaMAyHQWAio8HGsQUR4T37L7zzTz5/5uEH19fXd1x9zflvuO0PPvsH99zzxXfc+c5LL7l0aWkJES3zoZdf2NjYABBrWUR83//cH36u3+/VmpOhACBaE/DSy0TEZlirN9RFP8mrLwdrzyCgN7Vf6jth+W8sB6i8VGPbXBQzSnNk/cBRuWdV+0GdwMurg1yYaocZKUBrRek8+rQqyWItG2NMaBCVk9HDMJicnPzd3/udb37j71ApiYw5BTmXLmIfOz+38I53vuu1N9zYurJ1fHX1dz70i9976IEbb7j5X3zs46urq6EJh0Hwmc985oH77zPGZsqJifxG2whFUTTSEoaMghxMHHhbd/I6+tGf2O6yElK7bzEByPIPBZRiS5CUgiRriZqMgJVsm7qMXM3JkIQOekyPmjKgHyTuG8i4koUM/NlyGIZhaBCjED5bOxgMiDxEatQnrDGAgEBRPX7UVlUYo4Z8K6vrf/pHn/3TP/qsu2yt1vjABz74/vf/0yAIOt1uu9W65557/vE7f+/XWj55o6pv0ohgEQXVCDouCMK+8uG8d9DqMfvCFy1LvT0F+3+Czj4ZLD+hiNAOy2O2UXFJ+ryWp6WKekuXxfghHf3LFZYyMzBHOpclV7JbrLdGUNaKCa217Iq9LVtjrOdbIhJRRATaSwJ7lGqAp+IXXr3G7Gutf+anf2r/+fuvvPI1i4uLaxvrwyAwYYgEL774IpEm7TlPBwEsekBq1MrXtc0EAGBAGkpoH/wdvzU93DhM3Gle8lOD2kX09L8z/SVUfhUQKWqngFys+intt5dDk2ZOfVIhW3YniLshx+mVsohHtsUhAIq1NgyNMQYRjTEiElrDzElFARGk+01mjCQRAbJIFmyr1XrXu9/drDe3trZOnzktAkEYhGEY5ysQEJm0K58HVHFrH4qiLc5DJRIQQM90nrPbSkSmdl/HB34ZzjwaHPlbUYTWFHM0iaJyfYleTSO1HPPptA0Ya09OujxnjBsXTCEARcwsJGnrsljcmuCjnYwOwzBxWBzpmfMw9ZLoHaJFJUgACFQ/u7zSbDWHw6HbszAMg8BoHTVnZlKuRIQjblGCyAiEwBKFezEilxA1ENCabZq4nPssz/73oL+EykMYYrZpRLppgKQLA2LowXgseq6GBUpDlHnVGHUzYRBAIpCStGyhzgCYOQiD0ISxfhDL1towl3nIUdyhNy2SY0ImD/y6FRkOBqGxYRiGYeDsk14XrQCgRqCo8Xd0MlCUL1i3rNEbig1QAG3ogi4gbAXQr2++8DX/9I9M5xiRRmupAuJSdH1d4Xxp7DORJEnGitI1CsUOKfmASiRlLdGoVr4y0RcX2lprLLOx1ljrXEHnZ1epkaTFMhMwKhJE7YGugz8ZWu73e/1+v9/vDwbDIAh6w7AzGFoWIA+AHDZJEBmAtOKhfuN7fvGP7/1LnLoQyQfU4mnwfFFaiARRhEBxf+slFodDdqmQkuB4KiIfZxMQqGDalmUOBbEARK+Q5XG1CAAIq4S5x/9IkjAUZx0nlQDGWGs5rhEvQ5KgGCAGBQCilKgaSA1b8/0AtBkOgjApZRwa9n3PzXoAcaW/iGJB+2HAE4t7Fw4cePLICoDPSqHnM89CAKC6ItuEATipomrMjMDkWuzHGMZ8PDIlPsAdVUKsaAycbUIjJUGlYo1RuuhGREislBjz5diwpMozDMMYss/OVy4tZIvMcKdxWIkiqz1QNfDmmrsut8EwDAahiXKt0f5xjZkBkTWyFQREr24Gw8X9F19+/Q1f/dwf98+uUK2vPN8O/IN3v/fdd93yrz/5n+zpxwGAwBAIWBv1u4gq+aCigSyCCKamayRWRw6Lk65YjuAG4/GTmVvGAjeappDa9mp8HwuwNRwOA2ssIDJHSFQH94fCQeNoToZGVKCJlRLlk2qo+QPNHXv7nVUBFGtdnyBrLTrIJTMoRAEkFNJ2YC655nWL+/Y99Pf/e9jb9uq+MYqtTJ//mitvet3M3AICAWkUEbQoIoTCgqlFpB4pTRZOEp8QQ+aiuB6Mg5LmMyylaOUUjinCMET5IeZi1VthzyK0aBiGxhiJ4Azgfk0jEtJLjAQOEpPHqgZey6qpqYtvGqy9Mhh4nl9n6zIwI+QqEgIqUHUbBoh43R1vIaw9+HdfB7Dk63Bo0POuuOn25szOv/ovn/3z7T4OTyAAayLREopIENl/1SYaIrlWLkkXiGQ4SDpFV+rEIaIeA5YtIphiKkcZSsHyTG5ugAILG7bGmhRw36SLNtKWBiFY1AAkCpgU6DpgrbnvmskLD2x9/at0440AYoWjFpCAFgiVj14dvVoQBtM7Fi+/4ebjJ5ZPPPE9ailg4qHMXXDg4utuWllee/ab96DtesozwoAoULchgGcosGCNgAXgpKtUGlc0ojVELThTrcPO3RjXdfg7hxlY7HiA2WZTYwYTuCu4YHycs4pieGFo8jsvzp7TQh6TZqyBaqE/Ae3dO+/4JxsvPMbdFdKEIoSotQKt0fO0rk1MTKKwhHzhwVsPvOGOZ546vBY0rnr7e7m2oP2pA7fevevgO77/+KlDP3hAQR8htDIkBLa16QOvf/fHPtlYuKTUE86hLlL6sLLWegwGmqqgM1mwBybp7KisIO58ML61TmJmjAKkll0G1r0GJACxDjeGYFAJKUIQpayqSX3CSuv8t77TMPafvl8wBCFGBCJUmqhWr0/Mz868cuTYVuBf89b3+F79B1/7262e/pV/+cu//elfm77otktv/ZmVnj52eu3//fe/NHfNzWI9EM39AAR2XHLwx9/zU7/6kZ9uTi+Ki/0DJdAtKM1iOcs/Y4OUa6lKF7yqrihTBxfXSiR4bKkQZzlEehLsBwDLxsnXKP3qWuKBAIAFFEJRYFGL8lWtZW1r9xt/YuL8gy//5f8Q6HuNnSFjvV7nkLXvTTRq3U7vW488e2i1U9+17/CTj28vr59/w00XXXv1P3z70Nf+4QzK4OkffGN6cc8td73pyisu1PUGG6Oarb0XXzm39+LewP7vz3/+nj/9Cz77HClgw+eEmMbdXEoABaV5wjwQvcqvKylAAyGwFpFlJKHK4HqZCpT0zAIBYFHWmriiL4oHMmmLWiEBKFFtqLWsndp964/tvOO9L33l6+HGIW9mH9pVAq77rekJ7PaCR5458aOljvUbnfVjx599tr173xve91Zr8bknj213j3eWX243g+tvf53fXrzvi1/6+u/9MdXCvVfftLDv0s7GyvOPPdxfP+kQ68Qhc+Da5JQ5AhkcALAVFBS2AqXNQ3KFPEmJiR4TahjZdoBReQQgA7GxGIcLSy3oHBI3sTGYxVpxAjsIwrhXLlpAiwpJMXmia+C1rbT3vekte3/yA89+7R8HRx9pXXDDcPml4dJTi3M/JoxPHV57+Iwdst9bXzrx3HNqcv6ad/xUu90+cXRt6dRps/ZKY6r5mptubO887+XHHz/75N96E/VLL7546vwrj6zQY488Cusvgt0khcAhihHLKIDCCDad1QZIw8YTSw/BsqTqteIGuFV57bgjeunYnxKMx+h25IAEnK3HGtMEzvf9druNSMziCxtjYCitiRZoBNBCvoAVUqI06pboCVubu/Rtd87eevezX/1u//kfTO66dLB5vH/myQZNPfri9otB48wm8ubS8tOPhqguuPHW+X0Xbax2XnjomeHqsfaEv+/6G9vze04fO/L0t76ha3DZDa+ZmJtbOrV56IdHPvmbv3T2yCX/41O/TYqstcAW2DAIMhBbQE7nHHIQpFFoXzjqW11R55A7xO59XYqeOUfNcKpbdFW8P/2IL730Urfb7Xa7WmsRMcYaa9utxvr6OvoNJi1UA61F1S1O6pl9B9/3c3r/Nc/+9d/z1lLrgis7L94/OHvIv+DHZi+/9sH+5nD58MpzT5lQdl7/prnd52+eXv7ht+43vbXW3NR519xQm9p19sThF3/wv2p1uvSaa5stf/n06SMvPjG7+/yLr7tma9A7fXadCdCFTEc8xMnEhCosHYzmVGF1jUx5kxMRSfpHwxhjUKI6CrLDwezey2Tfm1e+/ycelQ+eyaKQRYQ7nQ5ImK5kdaF5qk1Ra5oRyWtaNSk4tePg6y571zvXVurHvvtQE4bWDDZPHvJmpnccODjRlOHxJ5aff5ZDmbv8ponFnZtnjq4cOWK2z87O1CYW9kh9Znlps3v8pK6b3Xv3eDRcXznT6/ZnF/bu2LV/feXE8onDw64FMYQbEnbBhmiGKIZFwFriEKIWnqUhm1h26Nbk4oHB2WeYWWtNpKJS1erYNCIyW11VIZMl3Ei/YoI7q4ivFmwPaDSbABB3hXVtvRXoGpNmXUdVN9zUi1ccuOttc1ff+PLjx1Yff8qDsG+2kfz5m9/dqEP/6EPHj75M2Ji77C3e5OT6yUOnH/iWCrqTE832gSut0KmTxwcrL81cd8sv/9r7vvTlx5ee/EeU/uzs4sz5e89smJOPPQH9V8Bsae0DaaN2QOsC6J7E3mmxNp65AGNwm5n+qHFHZYuAIITjYBoJrXUpq1eV6wOAZQvVrePyCP4khE0Owa2EPEASUqJ8UT5zS7X2XPSWH99/x5s2O/qJrz07PHWq0TD1ySlv+rJ+r985/Nj29tn61OLcZW+yYjZOH+4993DNU/Ozbe0vdLa2j7z0Egzt1AUXHLj1jj1XXHjw4EX3/t2PWrPnA5jl1ZPDtZd/9lc/eP7E7b/9id+UYMUMBVuz173z/Z/6+N0ffN8nzz6xpM41XaRoTEctwTFyY0pLuwotokCPNRvTHSYiMLqgIHFkcxBiNorI4CrxEQAskkWFLEgARACKlRJVF1IMHnBTTy9ecPNte2+7PWzOP/e9o+uHTk9O2h0Xz7PyO53h5vNP6KDXnFnQU7uCzurZwz+SYb/R8ncsztnhYG3l7HD7qJrZuffK6/fsXSCFm9vDh7/53N9/5TE5+wwPNlqt5iWvvVzt2FurwfJmAI3pHfOzE+0ZbC0Eg/Bv/ubB3sYyoXVsjMIQTT2AgvxNvSnJGNiYjhGYHqv4dRSSLpXRObhNEqS3xkwt7PEuuvPUD76geZty5UcRQhsYUFC5KbUAWohYe0i+FY/BB3+6tWvfvtfduPvG67re/InnNrZePtP2bWOuHnR6W+v94Xa37uua32TbG26eMd1NBaHvaeBg2Fnd3lgDRdO7L9p90eXt2elhp7t6cmlzdWvQWSYe1Go4szgzOz9jQ1hZX1tbXuv3oTW9MDelZNDvrB7bWDnOQwsBIG2RdNgyWEYOFdjCANc8oYUNejPthf3BynMWEDVpIEWqavJdps6wNHGVK3tP163boNPQHtSmod+xggQMIOza6DrWJRISQI+RGIlBW9QANdCT3ty+8y67dvfBK6YuuGC9o1883OufPd7Sw4WdzfWVzbXDa0Sq1Wq36g3T3+6tH7PBwNNY82DQXd1eWhVGPXve3huumj3vYr9W21jrH3rqaGdlSYIzvpKZpt+YXtRa+tsbLxx9xbKq11q+btcaPdk+fOLYst0+DTJAV4fnWQmsRO6TCDBDGnmOKXsu08KftCa2zIykSEaVnePniiEWHJZimVQGeQZg+x0kxtYc906J8kVCEmZQQgREAmAFBTSzYvTFn6b2fHt+cfbSy2cvvnJ6/3lcn9haC158djvc7pFh32ytrQ2NrdUatZn5NgZh2N3e6iyZ3haFHeltbHU32Ro1tTh/7esWL7ygMT3Z6/bPHFnePPm03TjpYa/hqfrMJAJzEKwcP2KGA/Jqym9o3R5YuOy112ycPvbKA48TdDSGwCLhABDAYR8QEAwgYx5eBGUGKwEAem3gkG1IpCoBtGUSWKf7tFX1nIZUj8JhGKrhWTVx3nDtOdQ+snIzIZg8VB7oGvo79MROf/a85q797b0XtHbu9qanlFcb9MJTR7u9zRMc9MKeCQYchujpWnNqwYMw7G12T58Zbp4Kt89Cbx24g7VmfW7f3mtvnL9gT601zf1g+eipo0/+qLt8yrPbNc/z23WgRhAOt9ZWAxsoVPVas95o+R7X6n5teppb05/4Z2976IGnf//b9yovEBMkEy+IgREQGA0LMKV6ZWSLo1KaTUQAlKpb2xXAKOZB49ImGY/Ryeiq+F7SpDZ5LzDD3Ze+bqt909rxh8HzEDXVWroxS40Z1Zz2JuZ1exGac6o1QXUPwmEY9sPeIOx2relZQWZS5Puq5vmoILSD7eH6mf7y4bC/Rhwo3/MnFhtze2huX21yJ6Bve+v95SP9tfVw4wzysOZpj0ILHpuhMSFobNRrzUatVtOeZ9AGHPQk7A66W52t7V43gOl93FuzZ18k2wcOBcQKIhtyTSCioj7GfCsHKEI7WBhAtxcv597xQWdLe15ceK3GuCCj5lWl827Lq7KiwdvUXTvW2PVm8acl3EDPZ1FsDA4GgEOwm7Q9BDxDSMwWENHzSBNoUlTzNSlllO0E2xvd9bPhoCtmQErXWhMTC/v0xCLVJ8CrGWM6m931o4/arbNgBp4mxYOGz4Aeki9eq1nztO83agoplLAXbK91V1b6m+u9zRXT34KgD2iBCEjBxgnFAYEBcfkCQbLEQTIHDTMwB86VxWfCOMxUn1a+DtY6qY6tcs6R2XmkUikSMpsrcYFTFWyttvuv+K35wcoZIsVGsViygdgB+ZvoTWJtgrSvPE+0RmSxzOHAmMEwGDicJ6Gn6wvehKe0QvKthZ7p29VlDo6CHaIYhYpY/JrG9hwqpT3tN5ue5yEJ2a70N7obSxsnlwbrp0xnA4YdkACAkIwCEY0oKMDAgihRuJvZAhBYtAYT+ZBpSyLnQoiz19wBwaYJA1J+MluptG9EMaWnq1y7qry4IhoMh+HykxMLbzEnt5l7aLbQb4PMIiIRi6DYgFFZVK6luDCChKA8QlSuQRqBMV0ZsrABEwIp8uukmt7EnPI0KSLQStXBE7Y9FfbBdIfrR7c3zoSbp8P+hgy2gQ1gACAkjCpEBgEDHCBbAAS2CWtKhHVGEqMkdGk/gtFI3fGWWUwoRt2otZrh1mEBotQ41jExokrz7pxjs6P3ye+debm5sLo9vd8sPYy6JqhFL4vXtKpG/hTVpqE+qWqTqtYk3QTtkfaJPASxAiAKFTIIKgWsGBgQFAAKCQRsejzohf1NG3Rtd9X2ViDo8nAAPAQISQKMELQW7dAlDpAtg0UBYRv5x8II6Ao7BIEEASyCEYk6/+TyFmPGpTr8KbDRzX1KwmFvm0i5qt4CCFSqcR2gixOfAWC8BU4EvX6/febx1s7bNpd+hGZIaISNhNuCCvC0RQ2gjKqxrgHVRddR+4ge6Tr6NUQPSBMRALMREQYO0XSt6dmgB2EAHIKEyCEiCyCy9USshMCWxDCwsEU3r4GARJDFYq68PKrRQwDFAGIADGT7PyWNDM79wwLUqk8u2K3DgbGe5+cyLBXFmVm4QbEhLpxrgK6ICOqN089Mzl403PP64ctfR7+J1oBCABJUSChAxF1lfEsEogFBgJhUBGVHFesccrl1jEY9GjdZDNmAuDEi1qHQEIRd7FjAvSkQzy8UUeysghj7FIHGXURfBAwAEIzGc1oAPFckKOkCAcZ4O/Zp3ux215AUlPXoL7a3ycoT1LkJG1VHKaNMAYmgH7D/yn3TF929sn7Arj0HflvYIjCCRSuILoM7FCIRBeRy9YSADuSZUu0OcO1oY125nLO6AARdfY4YAFHCEI8mA+dtCBq0IDiapyqMIMgRrEwAc1DxUU76XH5ztFYbqvZ8a2JyuPJsaMHzqNj4slQM5Iy38spZ9+PSernxF8nnlfK211amG/e1Lnrj5mAN+6dJtUVY4lbNDADIyCgiilCAJNYhnHGO4vF1IABI8Zl37EcSob9cpEyYURLXmGPFLygSlfdEzB6F2VzSviRGXDEqJN+7Aox4E62Z/bZ7bNDrKU0JDmyMMVca/lT1eqtol5SWFhWn5QhSsLXa9kXtvi1cP4HBKhGhWAcFi0LlbCOxIExuRItYFEtiiC2KBWGK3mQSi8IglphRGMUCWxRG4STz7ky2JCiuxJIIikVgYJvtxp1CJlaOesaK6QwIYgDrrfkDaFc6a6eQlFIeEbluZ7mBNUVOzaH3VKPRhmwf2OJYoqpj5VBU4daZyZaC894wXF/C4Qop7YrTlWteBs77GjVIQSczGRlTtqfrHOBgZlHnklQBWmQnRBchYBRLwAgsbrIOjDpzpzMjdI4lAJT3RiMQg9RoLFxRh+3e6hErSKSIdFyETKVUKg4oS15Es7JeJVCh+D4SMsNg40RLG2/frUEo3DmJAMrNH3USE0Q5g1cEwaBYAEFkiurn4rlwqcGaAFGjCpSoVguFERmFyWlIsAguiJxJkeXGMsI5NB6WNIoAsRwqf6a1cMCDje2VV1hIae2q/whdCy5VHC5U7OufJlee0KUBbChrXY+pubPMONw47fNaY89BaJ4fds4a0yEkiApsgAAIgWL5SiBufDSCRbEork6DEUSJIbFuDhSBIFsCATAIkQBJjdYYdZjN8FiujcC5ykwyjM1GRPsT+9o7zoPwTPfsMRZQnssNIjh3q2ws0PhwBwCoWr05Jlw3Hsc0Gk0LIKiGnTXVOdyaWcDF11qsw3ADwj4Ixxokit/iKB0Tj4uKumBZdwIAhEBAhACS4dqJw0vp/KXzGlzhXNR8JupXQpGCjSaTS+InZrwMN2DcZaQsA+rmQn3+knajbrZe6ayfFSSlfSKFruW3KyLPms9jPY9RJASnZxaqItal9YdFwZ9G6RljPJT69JxaeE1Is4ONpXDjMPdXyAwATHYyNthU87m4eBOTVgIwaqjgPokqnlMfN+McsQIlsZjRiIrR2IJRMWYMg3X7jIDsqhBVzavP+q0dnk88OD3YWB4GJu74phHREhCQShWdFMe9lTmWo7k2ODU9n/2QZHRCNWtXjKgRyyzGKBK/vUOmzvfqO4xVwbArQdcOO2z7IhxNYI+GoaNEToZ1Qhoh21k6KhaBeKZy3NQBjUt6ADDGChORXN9igZzZCvFYDifWFRGh8kg3yfM9j7SEdrAebK8MwwBIJR21stK2pKSwKjPrbC6KW9dFhIbMHHVIX3e881Jk/7iNoxXDgOL5yqvNUGMa6hOi6uDy7q5bSsSEHKU7o9pFABAkiq1xy2wJVTzaUxxXR04NcETDGA9AqJBI2HJkZceYuRHch11LAGEGsWJ7POxx0AuDrrEWIeoQmTRTy6q7pMMajMdEJ1CxBPqCU9NzWViqlGJVi748VI+4iBr8SOT1CLuBkuz6tqZkZWRlpMHHmYMSF0WP5qkXKgDTI+nH1e4V0UXi5pG7DqsIiEoREjGCQqSRfY3FadJlJnMSDUQomw+lqwgXz2OXYsi12OKjrLtKtPGICKCjVoSJQZ1IUIxbume79kVdT5FGBMo2AIlg6xhhuUadpCTnpkQpfERKRHcU20MArRREzr97M+q4J2kpXNqPpyg3pNhTPc2XOiFobmBTqjkwVGFNq/1XTA0DlihXpDDuK5bZ8LxjpnKtXEQEhFBAiKOTm9SHYVwkizxmjITKWXGWiSkySxQgAlpgRKWSvaS0OJYCOg7SvRqLKLhSAasLFyq18DOsnWvtVtXqOwXMHD10/Plcg6C0gZC0/UxldqI5CRC386eY0STyhVXJZuNoKmjaGAVFQNl6boI0dBFzK81axJTpEl+okC2NYbigUkmLPCwJeEG1kMExRc45jyH5Nbcf8Wako96jp8esykhsufQ3KtQ1ZlmMYss9bpPk8nNA2QZSlSG9hJGLab/SeUSZgs70VUrHRGVly6tyh6DYTb2s10Lp0G7IjiZ+FYW9mecvXMeNfUlVvsqof/CoqwJUzX2TnEQdEzyperYMyHE8tONVdk0YnxaqshErTtI57ScoTYwWMhhUtbvnvFdVAqUCpixV4EUALHHBxzjs/8fUrwqkjPm1NEZT9WxVoZhSxVPMJY1J3VWV54wha6mxQFCYFD9+AOuYMcWlYqvKpy9uUq5zXjHaW8pxY8Y+pxefLlsqUrl0iHShWzC+GmYq7RRe3t2gKu5Ruu3njD1BxRjW0iNZDBaWZiuKIqjoIBRTGVVcP2ZIXu6O4zVKBdfHhk3a2ynNqpQV0mJVWd14zVCkQo4FIDXouarStGp3x0jt9AWr5p2O0WPjr1klAHMsReNvM35KOZQVjuf+WjZeF8czfpXkqSxeqmbS4j69uu7C4zMyOOZh4htxbj4JjUF0JAXGOX6vms89RnqOn0oP55h2cw51N2bLS1XO+INVJEjVWnKDwbLbmYTkIhNTj7fGoKL3//hqryqra7xxlnN2So3iIo1e/W4VuT7XV3tcmVCZrqpab5mrLP8/TWnnZ+xUY5wAAAAASUVORK5CYII=" alt="HF Connect" style={{ width: "100%", height: "100%", objectFit: "cover" }} /></div>
              <div>
                <div style={{ fontSize: 16, fontWeight: 900 }}>HF Connect</div>
                <div style={{ fontSize: 12, color: "#64748b" }}>Tecnologia que conecta você</div>
              </div>
            </div>
            <p style={{ fontSize: 14, color: "#64748b", lineHeight: 1.8, maxWidth: 320 }}>Fibra óptica, câmeras, Starlink, Wi‑Fi e infraestrutura de redes para residências, empresas e propriedades rurais.</p>
          </div>
          <div>
            <div style={{ fontWeight: 900, marginBottom: 16 }}>Serviços</div>
            {["Fibra óptica","Câmeras de segurança","Starlink e Wi‑Fi","Redes e suporte técnico"].map(s => (
              <a key={s} href="#servicos" style={{ display: "block", fontSize: 13, color: "#64748b", textDecoration: "none", marginBottom: 10 }}
                onMouseOver={e => e.target.style.color="#7dd3fc"} onMouseOut={e => e.target.style.color="#64748b"}>{s}</a>
            ))}
          </div>
          <div>
            <div style={{ fontWeight: 900, marginBottom: 16 }}>Contato</div>
            <a href={whatsappLink} target="_blank" rel="noreferrer" style={{ display: "block", fontSize: 13, color: "#64748b", textDecoration: "none", marginBottom: 10 }}>WhatsApp: inserir número</a>
            <div style={{ fontSize: 13, color: "#64748b", marginBottom: 10 }}>Patos de Minas e região</div>
            <div style={{ fontSize: 13, color: "#64748b" }}>© {new Date().getFullYear()} HF Connect</div>
          </div>
        </div>
      </footer>
    </div>
  );
}
